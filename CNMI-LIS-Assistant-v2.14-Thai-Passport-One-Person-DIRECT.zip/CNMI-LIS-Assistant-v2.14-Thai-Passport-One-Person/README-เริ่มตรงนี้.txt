CNMI LIS Assistant v2.14

1. เปิด Start-LIS-Assistant.cmd
2. เลือก CNMI-LIS-*.csv ที่ Export จาก Blood Mobile v15.6.45 ขึ้นไป
3. ทำทีละคนให้จบทั้งส่วนที่ 1 และส่วนที่ 2

คนไทย
- ค้นด้วย Donor ID ก่อน ถ้าไม่มีใช้เลขบัตร 13 หลัก
- Auto ส่วนที่ 1 ลงเลขบัตรประชาชน

ต่างชาติ / Passport
- ถ้ามี Donor ID ใช้ Donor ID ค้นก่อน
- ถ้ายังไม่มี Donor ID โปรแกรมจะคัดลอก Passport Number ให้ แล้วให้ใช้ AI-LIS > ค้นหาโดยละเอียด > Passport Number
- Auto ส่วนที่ 1 จะข้ามช่องเลขบัตรประชาชนและลง Passport Number

สำคัญ: ตรวจชื่อใน AI-LIS ให้ตรงกับชื่อใหญ่ใน Assistant ก่อน Auto ทุกครั้ง
