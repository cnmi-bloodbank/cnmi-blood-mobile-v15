﻿CNMI LIS Assistant v2.12 — เริ่มใช้งาน

1. แตก ZIP ไว้ในเครื่อง Windows
2. เปิด Start-LIS-Assistant.cmd
3. เปิดไฟล์ CNMI-LIS-*.csv ที่ Export จาก Blood Mobile

ส่วนที่ 1 — ข้อมูลผู้บริจาค
- ค้น AI-LIS และยืนยันชื่อก่อน Auto
- Auto ถึงอาชีพและโทรศัพท์
- อาชีพจะพิมพ์และกด Enter ยืนยัน dropdown ของ AI-LIS

ส่วนที่ 2 — ผลคัดกรอง
กรณี “ผ่าน”
- ต้องมี Bag Number + Bag Lot
- ต้องยิง Barcode ถุงให้ตรง Expected Bag
- Auto: Weight → BP → Pulse → Temperature → Hb → Bag → V → Group → Bag Lot

กรณี “ไม่ผ่าน”
- ไม่ต้องยิง Barcode ถุง
- ไม่ต้องมี Bag Number / Group / Bag Lot
- Auto: Weight → BP → Pulse → Temperature → Hb แล้วหยุดทันที
- ตรวจค่าและกดบันทึกใน AI-LIS จากนั้นกลับมากด ✓ ตรวจและบันทึกแล้ว

หมายเหตุ: โปรแกรมเป็น Local Only และไม่เชื่อม API กับ AI-LIS จึงต้องตรวจชื่อ/ค่าบนหน้าจอก่อนบันทึกทุกครั้ง
