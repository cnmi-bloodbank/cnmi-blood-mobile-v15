@echo off
chcp 65001 >nul
title CNMI Scan Bridge v1.3
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CNMI-Scan-Bridge.ps1"
