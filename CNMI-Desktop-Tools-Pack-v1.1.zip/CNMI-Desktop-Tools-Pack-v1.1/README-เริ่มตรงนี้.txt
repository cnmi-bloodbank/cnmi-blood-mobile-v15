CNMI Desktop Tools Pack v1.0
สำหรับคอม Windows ที่ใช้ Blood Mobile

มี 3 โปรแกรม

1) CNMI Card Bridge v1.0
   ใช้กับปุ่ม “อ่านบัตรประชาชน”
   เปิด: CNMI-Card-Bridge-v1.0\Start-CNMI-Card-Bridge.cmd
   ให้เปิดค้างไว้ระหว่างใช้เครื่องอ่านบัตร

2) CNMI Scan Bridge v1.3
   ใช้กับปุ่ม “สแกนบัตร / ใบขับขี่”
   เปิด: CNMI-Scan-Bridge-v1.2\Start-CNMI-Scan-Bridge.cmd
   ให้เปิดค้างไว้ระหว่างใช้ Scanner

3) CNMI LIS Assistant v2.12
   ใช้ตอนนำข้อมูลผู้บริจาค/ผลคัดกรองจาก CSV ไปช่วยกรอก AI-LIS
   เปิด Start-LIS-Assistant.cmd ในโฟลเดอร์ LIS Assistant
   ไม่ต้องเปิดค้างตลอด เปิดเฉพาะเวลาจะทำงานกับ AI-LIS

เวลาเปลี่ยนคอม
- ดาวน์โหลด Pack นี้จากเมนู “เตรียมออกหน่วย”
- แตก ZIP ไว้ในโฟลเดอร์ที่หาเจอง่าย เช่น Desktop\CNMI Tools
- ไม่ต้องติดตั้ง Blood Mobile ใหม่ เพราะ Blood Mobile เปิดจากเว็บ
