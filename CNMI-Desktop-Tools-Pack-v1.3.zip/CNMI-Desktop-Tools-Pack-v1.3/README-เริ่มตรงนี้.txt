CNMI Desktop Tools Pack v1.3

1) Card Bridge v1.0 — อ่านบัตรประชาชนไทย
2) Scan Bridge v1.3 — Scanner สำหรับบัตร / Passport
3) LIS Assistant v2.14 — Thai + Passport / ทำทีละคนให้จบ

ให้แตก ZIP ของโปรแกรมที่ต้องใช้ แล้วเปิดไฟล์ Start-*.cmd ตามงานนั้น
