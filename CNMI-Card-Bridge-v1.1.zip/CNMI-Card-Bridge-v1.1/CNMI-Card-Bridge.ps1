﻿# CNMI Card Bridge v1.1
# Local-only bridge: Blood Mobile (browser) -> Windows Smart Card / Thai National ID
# Uses Windows Smart Card API (winscard.dll). No donor/card data is stored or uploaded by this bridge.

$ErrorActionPreference = 'Stop'
$Port = 27100

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class WinSCardCNMI {
    public const uint SCARD_SCOPE_USER = 0;
    public const uint SCARD_SHARE_SHARED = 2;
    public const uint SCARD_PROTOCOL_T0 = 1;
    public const uint SCARD_PROTOCOL_T1 = 2;
    public const uint SCARD_LEAVE_CARD = 0;

    [StructLayout(LayoutKind.Sequential)]
    public struct SCARD_IO_REQUEST {
        public uint dwProtocol;
        public uint cbPciLength;
    }

    [DllImport("winscard.dll")]
    public static extern int SCardEstablishContext(uint dwScope, IntPtr pvReserved1, IntPtr pvReserved2, out IntPtr phContext);

    [DllImport("winscard.dll", CharSet = CharSet.Unicode)]
    public static extern int SCardListReaders(IntPtr hContext, string mszGroups, char[] mszReaders, ref int pcchReaders);

    [DllImport("winscard.dll", CharSet = CharSet.Unicode)]
    public static extern int SCardConnect(IntPtr hContext, string szReader, uint dwShareMode, uint dwPreferredProtocols, out IntPtr phCard, out uint pdwActiveProtocol);

    [DllImport("winscard.dll")]
    public static extern int SCardTransmit(IntPtr hCard, ref SCARD_IO_REQUEST pioSendPci, byte[] pbSendBuffer, int cbSendLength, IntPtr pioRecvPci, byte[] pbRecvBuffer, ref int pcbRecvLength);

    [DllImport("winscard.dll")]
    public static extern int SCardDisconnect(IntPtr hCard, uint dwDisposition);

    [DllImport("winscard.dll")]
    public static extern int SCardReleaseContext(IntPtr hContext);
}
"@

function New-Json([hashtable]$obj) {
    return ($obj | ConvertTo-Json -Compress -Depth 8)
}

function Send-HttpResponse {
    param(
        [System.Net.Sockets.TcpClient]$Client,
        [int]$StatusCode = 200,
        [string]$StatusText = 'OK',
        [string]$ContentType = 'application/json; charset=utf-8',
        [string]$Body = ''
    )
    $stream = $Client.GetStream()
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    $bodyBytes = $utf8.GetBytes($Body)
    $headers = "HTTP/1.1 $StatusCode $StatusText`r`n" +
               "Content-Type: $ContentType`r`n" +
               "Content-Length: $($bodyBytes.Length)`r`n" +
               "Access-Control-Allow-Origin: *`r`n" +
               "Access-Control-Allow-Methods: GET, OPTIONS`r`n" +
               "Access-Control-Allow-Headers: Content-Type`r`n" +
               "Access-Control-Allow-Private-Network: true`r`n" +
               "Cache-Control: no-store`r`n" +
               "Connection: close`r`n`r`n"
    $headerBytes = $utf8.GetBytes($headers)
    $stream.Write($headerBytes,0,$headerBytes.Length)
    if($bodyBytes.Length -gt 0){ $stream.Write($bodyBytes,0,$bodyBytes.Length) }
    $stream.Flush()
}

function Assert-SCardOk([int]$Code, [string]$Step) {
    if($Code -ne 0){ throw "$Step ไม่สำเร็จ (Smart Card error 0x$('{0:X8}' -f ([uint32]$Code)))" }
}

function Get-SmartCardReaders([IntPtr]$Context) {
    $len = 0
    $rc = [WinSCardCNMI]::SCardListReaders($Context, $null, $null, [ref]$len)
    Assert-SCardOk $rc 'ค้นหาเครื่องอ่านบัตร'
    if($len -le 1){ return @() }
    $buf = New-Object char[] $len
    $rc = [WinSCardCNMI]::SCardListReaders($Context, $null, $buf, [ref]$len)
    Assert-SCardOk $rc 'อ่านรายชื่อเครื่องอ่านบัตร'
    $all = -join $buf
    return @($all.Split([char]0) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
}

function Invoke-CardTransmit {
    param([IntPtr]$Card, [uint32]$Protocol, [byte[]]$Command)
    $pci = New-Object WinSCardCNMI+SCARD_IO_REQUEST
    $pci.dwProtocol = $Protocol
    $pci.cbPciLength = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($pci)
    $recv = New-Object byte[] 4096
    $recvLen = $recv.Length
    $rc = [WinSCardCNMI]::SCardTransmit($Card, [ref]$pci, $Command, $Command.Length, [IntPtr]::Zero, $recv, [ref]$recvLen)
    Assert-SCardOk $rc 'สื่อสารกับบัตร'
    if($recvLen -lt 2){ throw 'บัตรตอบกลับไม่ครบ' }
    return [byte[]]$recv[0..($recvLen-1)]
}

function Invoke-ThaiIdCommand {
    param([IntPtr]$Card, [uint32]$Protocol, [byte[]]$Command)
    $r = Invoke-CardTransmit -Card $Card -Protocol $Protocol -Command $Command
    $sw1 = $r[$r.Length-2]; $sw2 = $r[$r.Length-1]
    if($sw1 -eq 0x61){
        $getResp = [byte[]](0x00,0xC0,0x00,0x00,$sw2)
        $r = Invoke-CardTransmit -Card $Card -Protocol $Protocol -Command $getResp
        $sw1 = $r[$r.Length-2]; $sw2 = $r[$r.Length-1]
    } elseif($sw1 -eq 0x6C){
        $fixed = [byte[]]$Command.Clone()
        $fixed[$fixed.Length-1] = $sw2
        $r = Invoke-CardTransmit -Card $Card -Protocol $Protocol -Command $fixed
        $sw1 = $r[$r.Length-2]; $sw2 = $r[$r.Length-1]
    }
    if($sw1 -ne 0x90 -or $sw2 -ne 0x00){ throw "บัตรไม่ยอมรับคำสั่ง (SW=$('{0:X2}{1:X2}' -f $sw1,$sw2))" }
    if($r.Length -le 2){ return [byte[]]@() }
    return [byte[]]$r[0..($r.Length-3)]
}

function Decode-ThaiCardText([byte[]]$Bytes) {
    if($null -eq $Bytes -or $Bytes.Length -eq 0){ return '' }
    try { $enc = [System.Text.Encoding]::GetEncoding(874) } catch { $enc = [System.Text.Encoding]::Default }
    return $enc.GetString($Bytes).Trim([char[]]@(0,32,255)).Trim()
}

function Decode-AsciiCardText([byte[]]$Bytes) {
    if($null -eq $Bytes -or $Bytes.Length -eq 0){ return '' }
    return [System.Text.Encoding]::ASCII.GetString($Bytes).Trim([char[]]@(0,32,255)).Trim()
}

function Clean-CardName([string]$Value) {
    return (($Value -replace '#+',' ') -replace '\s+',' ').Trim()
}

function Parse-ThaiFullName([string]$Raw) {
    $parts = @($Raw.Split('#') | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
    if($parts.Count -ge 3){ return @{prefix=$parts[0]; firstName=$parts[1]; lastName=$parts[$parts.Count-1]} }
    $clean = Clean-CardName $Raw
    return @{prefix='';firstName=$clean;lastName=''}
}

function Format-ThaiBirth([string]$Raw) {
    $digits = ($Raw -replace '\D','')
    if($digits.Length -ge 8){
        $yyyy=$digits.Substring(0,4); $mm=$digits.Substring(4,2); $dd=$digits.Substring(6,2)
        return "$dd-$mm-$yyyy"
    }
    return $Raw.Trim()
}

function Read-ThaiNationalId {
    $ctx = [IntPtr]::Zero
    $card = [IntPtr]::Zero
    try {
        $rc = [WinSCardCNMI]::SCardEstablishContext([WinSCardCNMI]::SCARD_SCOPE_USER,[IntPtr]::Zero,[IntPtr]::Zero,[ref]$ctx)
        Assert-SCardOk $rc 'เปิด Windows Smart Card'
        $readers = Get-SmartCardReaders $ctx
        if($readers.Count -eq 0){ throw 'ไม่พบเครื่องอ่านบัตร Smart Card ใน Windows' }

        $lastError = $null
        foreach($reader in $readers){
            try {
                $proto = [uint32]0
                $rc = [WinSCardCNMI]::SCardConnect($ctx,$reader,[WinSCardCNMI]::SCARD_SHARE_SHARED,([WinSCardCNMI]::SCARD_PROTOCOL_T0 -bor [WinSCardCNMI]::SCARD_PROTOCOL_T1),[ref]$card,[ref]$proto)
                if($rc -ne 0){ $lastError = "เชื่อมต่อ $reader ไม่สำเร็จ"; continue }

                # Thai National ID application
                [void](Invoke-ThaiIdCommand -Card $card -Protocol $proto -Command ([byte[]](0x00,0xA4,0x04,0x00,0x08,0xA0,0x00,0x00,0x00,0x54,0x48,0x00,0x01)))
                $cid = Decode-AsciiCardText (Invoke-ThaiIdCommand -Card $card -Protocol $proto -Command ([byte[]](0x80,0xB0,0x00,0x04,0x02,0x00,0x0D)))
                if($cid -notmatch '^\d{13}$'){ throw 'อ่านเลขบัตรประชาชน 13 หลักไม่ได้' }
                $thNameRaw = Decode-ThaiCardText (Invoke-ThaiIdCommand -Card $card -Protocol $proto -Command ([byte[]](0x80,0xB0,0x00,0x11,0x02,0x00,0x64)))
                $birthRaw = Decode-AsciiCardText (Invoke-ThaiIdCommand -Card $card -Protocol $proto -Command ([byte[]](0x80,0xB0,0x00,0xD9,0x02,0x00,0x08)))
                $genderRaw = Decode-AsciiCardText (Invoke-ThaiIdCommand -Card $card -Protocol $proto -Command ([byte[]](0x80,0xB0,0x00,0xE1,0x02,0x00,0x01)))
                $addressRaw = Decode-ThaiCardText (Invoke-ThaiIdCommand -Card $card -Protocol $proto -Command ([byte[]](0x80,0xB0,0x15,0x79,0x02,0x00,0x64)))
                $name = Parse-ThaiFullName $thNameRaw
                $gender = if($genderRaw.Trim() -eq '1'){'ชาย'}elseif($genderRaw.Trim() -eq '2'){'หญิง'}else{$genderRaw.Trim()}
                $address = Clean-CardName $addressRaw
                return @{ok=$true;citizenId=$cid;prefix=$name.prefix;firstName=$name.firstName;lastName=$name.lastName;birthDate=(Format-ThaiBirth $birthRaw);gender=$gender;address=$address;reader=$reader;version='1.1'}
            } catch {
                $lastError = $_.Exception.Message
            } finally {
                if($card -ne [IntPtr]::Zero){ [void][WinSCardCNMI]::SCardDisconnect($card,[WinSCardCNMI]::SCARD_LEAVE_CARD); $card=[IntPtr]::Zero }
            }
        }
        if($lastError){ throw $lastError } else { throw 'ไม่พบบัตรประชาชนในเครื่องอ่าน' }
    } finally {
        if($card -ne [IntPtr]::Zero){ [void][WinSCardCNMI]::SCardDisconnect($card,[WinSCardCNMI]::SCARD_LEAVE_CARD) }
        if($ctx -ne [IntPtr]::Zero){ [void][WinSCardCNMI]::SCardReleaseContext($ctx) }
    }
}

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback,$Port)
try { $listener.Start() } catch {
    Write-Host ''
    Write-Host "เปิด CNMI Card Bridge ไม่สำเร็จ: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'ถ้ามี Card Bridge เปิดอยู่แล้ว ให้ปิดหน้าต่างเดิมก่อน' -ForegroundColor Yellow
    Read-Host 'กด Enter เพื่อปิด'
    exit 1
}

Write-Host 'CNMI Card Bridge v1.1' -ForegroundColor Cyan
Write-Host "พร้อมใช้งานที่ http://127.0.0.1:$Port" -ForegroundColor Green
Write-Host 'เสียบบัตรประชาชนใน Smart Card Reader แล้วกด อ่านบัตรประชาชน จาก Blood Mobile' -ForegroundColor Yellow
Write-Host 'ข้อมูลบัตรส่งให้ Browser ในเครื่องนี้เท่านั้น และ Bridge ไม่บันทึกข้อมูลไว้' -ForegroundColor DarkGray
Write-Host ''

try {
    while($true){
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream,[System.Text.Encoding]::ASCII,$false,4096,$true)
            $requestLine = $reader.ReadLine()
            if([string]::IsNullOrWhiteSpace($requestLine)){
                Send-HttpResponse -Client $client -StatusCode 400 -StatusText 'Bad Request' -Body (New-Json @{ok=$false;message='Bad request'})
                continue
            }
            do { $line=$reader.ReadLine() } while($null -ne $line -and $line -ne '')
            $parts = $requestLine.Split(' ')
            $method = if($parts.Length -gt 0){$parts[0]}else{''}
            $path = if($parts.Length -gt 1){$parts[1].Split('?')[0]}else{'/'}

            if($method -eq 'OPTIONS'){
                Send-HttpResponse -Client $client -StatusCode 204 -StatusText 'No Content' -Body ''
            } elseif($method -ne 'GET'){
                Send-HttpResponse -Client $client -StatusCode 405 -StatusText 'Method Not Allowed' -Body (New-Json @{ok=$false;message='GET only'})
            } elseif($path -eq '/health'){
                Send-HttpResponse -Client $client -Body (New-Json @{ok=$true;name='CNMI Card Bridge';version='1.1';port=$Port})
            } elseif($path -eq '/read'){
                Write-Host ('[' + (Get-Date -Format 'HH:mm:ss') + '] อ่านบัตรประชาชน...') -ForegroundColor Cyan
                try {
                    $result = Read-ThaiNationalId
                    Write-Host ('อ่านสำเร็จ · *********' + $result.citizenId.Substring(9,4) + ' · ' + $result.firstName + ' ' + $result.lastName) -ForegroundColor Green
                    Send-HttpResponse -Client $client -Body (New-Json $result)
                } catch {
                    $msg = $_.Exception.Message
                    Write-Host ('อ่านไม่สำเร็จ: ' + $msg) -ForegroundColor Red
                    Send-HttpResponse -Client $client -Body (New-Json @{ok=$false;message=$msg;version='1.1'})
                }
            } else {
                Send-HttpResponse -Client $client -StatusCode 404 -StatusText 'Not Found' -Body (New-Json @{ok=$false;message='Not found'})
            }
        } catch {
            try { Send-HttpResponse -Client $client -StatusCode 500 -StatusText 'Internal Server Error' -Body (New-Json @{ok=$false;message=$_.Exception.Message}) } catch {}
        } finally {
            try { $client.Close() } catch {}
        }
    }
} finally {
    try { $listener.Stop() } catch {}
}
