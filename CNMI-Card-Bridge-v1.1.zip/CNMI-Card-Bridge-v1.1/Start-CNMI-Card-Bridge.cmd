@echo off
chcp 65001 >nul
title CNMI Card Bridge v1.1
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0CNMI-Card-Bridge.ps1"
if errorlevel 1 pause
