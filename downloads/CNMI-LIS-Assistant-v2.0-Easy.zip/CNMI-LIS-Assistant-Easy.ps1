# CNMI LIS Assistant v2.0 Easy Workflow
# Local-only helper for entering CNMI Blood Mobile CSV data into AI-LIS.
# No donor data is uploaded by this program.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:rows = @()
$script:csvPath = ''
$script:progressPath = ''
$script:regDone = @{}
$script:interviewDone = @{}
$script:phase = 'registration'
$script:regFieldIndex = 0
$script:delayMs = 350
$script:countdownSeconds = 3

function S([object]$v) { if ($null -eq $v) { return '' }; return ([string]$v).Trim() }
function RowKey($row) {
    $dn = S $row.DN
    if ($dn) { return 'DN:' + $dn }
    return 'ID:' + (S $row.ID_Card) + '|BAG:' + (S $row.Bag_Number)
}
function MaskId([string]$id) {
    $id = S $id
    if ($id.Length -le 4) { return $id }
    return ('*' * [Math]::Max(0,$id.Length-4)) + $id.Substring($id.Length-4)
}
function ThaiGender([string]$v) {
    $x = (S $v).ToUpper()
    if ($x -in @('M','MALE','ชาย')) { return 'ชาย' }
    if ($x -in @('F','FEMALE','หญิง')) { return 'หญิง' }
    return S $v
}
function LastDonationNo($row) {
    $v = S $row.Last_Donation_No
    if ($v -match '^\d+$') { return $v }
    $cur = S $row.Donation_No
    if ($cur -match '^\d+$') { return [string][Math]::Max(0,([int]$cur)-1) }
    return ''
}
function CurrentDonationNo($row) {
    $v = S $row.Donation_No
    if ($v -match '^\d+$') { return $v }
    $last = LastDonationNo $row
    if ($last -match '^\d+$') { return [string](([int]$last)+1) }
    return ''
}
function GetVisitDate($row) {
    $v = S $row.Visit_Date
    if ($v -match '^(\d{4})-(\d{2})-(\d{2})$') { return "$($Matches[3])/$($Matches[2])/$($Matches[1])" }
    return $v
}
function GetSearchValue($row) {
    $did = S $row.Donor_ID
    if ($did) { return @{ Label='Donor ID'; Value=$did } }
    return @{ Label='เลขบัตรประชาชน'; Value=(S $row.ID_Card) }
}
function GetRowValue($row,[string]$field) {
    switch ($field) {
        'ID_Card' { return S $row.ID_Card }
        'Prefix' { return S $row.Prefix }
        'FirstName' { return S $row.FirstName }
        'LastName' { return S $row.LastName }
        'Birthdate' { return S $row.Birthdate }
        'Last_Donation_No' { return LastDonationNo $row }
        'Gender' { return ThaiGender $row.Gender }
        'Address' { return S $row.Address }
        'Subdistrict' { return S $row.Subdistrict }
        'District' { return S $row.District }
        'Province' { return S $row.Province }
        'Postal_Code' { return S $row.Postal_Code }
        'Occupation' { return S $row.Occupation }
        'Phone' { return S $row.Phone }
        'Email' { return S $row.Email }
        'Weight' { return S $row.Weight }
        'BP' { return S $row.BP }
        'Pulse' { return S $row.Pulse }
        'Temperature' { return S $row.Temperature }
        'Hb' { return S $row.Hb }
        'Bag_Number' { return S $row.Bag_Number }
        'Visit_Date' { return GetVisitDate $row }
        'Location' { return S $row.Location }
        default { return S $row.$field }
    }
}

$script:regFields = @(
    @{ Key='ID_Card'; Label='เลขบัตรประชาชน' },
    @{ Key='Prefix'; Label='คำนำหน้า' },
    @{ Key='FirstName'; Label='ชื่อ' },
    @{ Key='LastName'; Label='นามสกุล' },
    @{ Key='Birthdate'; Label='วันเดือนปีเกิด' },
    @{ Key='Last_Donation_No'; Label='บริจาคล่าสุดครั้งที่' },
    @{ Key='Gender'; Label='เพศ' },
    @{ Key='Address'; Label='ที่อยู่' },
    @{ Key='Subdistrict'; Label='ตำบล' },
    @{ Key='District'; Label='อำเภอ' },
    @{ Key='Province'; Label='จังหวัด' },
    @{ Key='Postal_Code'; Label='รหัสไปรษณีย์' },
    @{ Key='Occupation'; Label='อาชีพ' },
    @{ Key='Phone'; Label='โทรศัพท์' },
    @{ Key='Email'; Label='อีเมล' }
)
$script:autoInterviewFields = @('Weight','BP','Pulse','Temperature','Hb')

function LoadProgress {
    $script:regDone = @{}
    $script:interviewDone = @{}
    if (-not $script:progressPath -or -not (Test-Path $script:progressPath)) { return }
    try {
        $p = Get-Content $script:progressPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @($p.registrationDone)) { if (S $k) { $script:regDone[(S $k)] = $true } }
        foreach ($k in @($p.interviewDone)) { if (S $k) { $script:interviewDone[(S $k)] = $true } }
    } catch { }
}
function SaveProgress {
    if (-not $script:progressPath) { return }
    try {
        $obj = [ordered]@{
            version = 1
            csv = [System.IO.Path]::GetFileName($script:csvPath)
            updatedAt = (Get-Date).ToString('s')
            registrationDone = @($script:regDone.Keys)
            interviewDone = @($script:interviewDone.Keys)
        }
        $obj | ConvertTo-Json -Depth 4 | Set-Content -Path $script:progressPath -Encoding UTF8
    } catch { }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'CNMI LIS Assistant v2.0 — ง่าย 2 ขั้น'
$form.Size = New-Object System.Drawing.Size(1280,850)
$form.MinimumSize = New-Object System.Drawing.Size(1100,720)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)

$top = New-Object System.Windows.Forms.Panel
$top.Dock='Top'; $top.Height=150; $top.Padding='12,10,12,8'; $form.Controls.Add($top)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text='CNMI LIS Assistant — ทำตาม 2 ขั้น'; $lblTitle.Font=New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold); $lblTitle.AutoSize=$true; $lblTitle.Left=12; $lblTitle.Top=8; $top.Controls.Add($lblTitle)

$btnNewest = New-Object System.Windows.Forms.Button
$btnNewest.Text='เปิด CSV ล่าสุดใน Downloads'; $btnNewest.Width=210; $btnNewest.Height=36; $btnNewest.Left=12; $btnNewest.Top=45; $top.Controls.Add($btnNewest)
$btnOpen = New-Object System.Windows.Forms.Button
$btnOpen.Text='เลือกไฟล์ CSV อื่น'; $btnOpen.Width=150; $btnOpen.Height=36; $btnOpen.Left=232; $btnOpen.Top=45; $top.Controls.Add($btnOpen)
$lblFile = New-Object System.Windows.Forms.Label
$lblFile.Text='ยังไม่ได้เปิดไฟล์'; $lblFile.AutoSize=$true; $lblFile.Left=395; $lblFile.Top=55; $top.Controls.Add($lblFile)

$btnPhase1 = New-Object System.Windows.Forms.Button
$btnPhase1.Text='① ลงข้อมูลผู้บริจาค'; $btnPhase1.Width=240; $btnPhase1.Height=46; $btnPhase1.Left=12; $btnPhase1.Top=92; $btnPhase1.Font=New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold); $top.Controls.Add($btnPhase1)
$btnPhase2 = New-Object System.Windows.Forms.Button
$btnPhase2.Text='② สัมภาษณ์ / ลงผล'; $btnPhase2.Width=240; $btnPhase2.Height=46; $btnPhase2.Left=262; $btnPhase2.Top=92; $btnPhase2.Font=New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold); $top.Controls.Add($btnPhase2)

$lblCounts = New-Object System.Windows.Forms.Label
$lblCounts.Text='รวม 0 คน · ขั้น 1: 0/0 · ขั้น 2: 0/0'; $lblCounts.AutoSize=$true; $lblCounts.Left=525; $lblCounts.Top=106; $lblCounts.Font=New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold); $lblCounts.ForeColor='DarkBlue'; $top.Controls.Add($lblCounts)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock='Fill'; $grid.ReadOnly=$true; $grid.SelectionMode='FullRowSelect'; $grid.MultiSelect=$false; $grid.AllowUserToAddRows=$false; $grid.AllowUserToDeleteRows=$false; $grid.AutoSizeColumnsMode='Fill'; $grid.RowHeadersVisible=$false; $form.Controls.Add($grid)

$bottom = New-Object System.Windows.Forms.Panel
$bottom.Dock='Bottom'; $bottom.Height=285; $bottom.Padding='12,8,12,8'; $form.Controls.Add($bottom)

$lblSelected = New-Object System.Windows.Forms.Label
$lblSelected.Text='ยังไม่ได้เลือกรายการ'; $lblSelected.AutoSize=$true; $lblSelected.Left=12; $lblSelected.Top=10; $lblSelected.Font=New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold); $bottom.Controls.Add($lblSelected)

$lblMini = New-Object System.Windows.Forms.Label
$lblMini.Text=''; $lblMini.AutoSize=$true; $lblMini.Left=12; $lblMini.Top=38; $lblMini.ForeColor='DimGray'; $bottom.Controls.Add($lblMini)

$regPanel = New-Object System.Windows.Forms.Panel
$regPanel.Left=12; $regPanel.Top=66; $regPanel.Width=1230; $regPanel.Height=205; $bottom.Controls.Add($regPanel)

$lblRegStep = New-Object System.Windows.Forms.Label
$lblRegStep.Text='ใน AI-LIS เปิดแท็บ “ข้อมูลผู้บริจาคโลหิต”'; $lblRegStep.AutoSize=$true; $lblRegStep.Left=0; $lblRegStep.Top=0; $lblRegStep.ForeColor='DarkGreen'; $lblRegStep.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold); $regPanel.Controls.Add($lblRegStep)

$btnCopySearch = New-Object System.Windows.Forms.Button
$btnCopySearch.Text='1) คัดลอกเลขค้นหา'; $btnCopySearch.Width=190; $btnCopySearch.Height=42; $btnCopySearch.Left=0; $btnCopySearch.Top=32; $btnCopySearch.BackColor='AliceBlue'; $regPanel.Controls.Add($btnCopySearch)
$btnCopyId = New-Object System.Windows.Forms.Button
$btnCopyId.Text='คัดลอกเลขบัตร'; $btnCopyId.Width=145; $btnCopyId.Height=42; $btnCopyId.Left=200; $btnCopyId.Top=32; $regPanel.Controls.Add($btnCopyId)

$lblNext = New-Object System.Windows.Forms.Label
$lblNext.Text='ช่องถัดไป: -'; $lblNext.AutoSize=$true; $lblNext.Left=0; $lblNext.Top=86; $lblNext.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold); $regPanel.Controls.Add($lblNext)

$btnNextField = New-Object System.Windows.Forms.Button
$btnNextField.Text='2) คัดลอกช่องถัดไป'; $btnNextField.Width=190; $btnNextField.Height=42; $btnNextField.Left=0; $btnNextField.Top=115; $regPanel.Controls.Add($btnNextField)
$btnPasteNext = New-Object System.Windows.Forms.Button
$btnPasteNext.Text='วางช่องนี้ใน 3 วิ'; $btnPasteNext.Width=170; $btnPasteNext.Height=42; $btnPasteNext.Left=200; $btnPasteNext.Top=115; $btnPasteNext.BackColor='LightYellow'; $regPanel.Controls.Add($btnPasteNext)
$btnResetField = New-Object System.Windows.Forms.Button
$btnResetField.Text='เริ่มช่องแรกใหม่'; $btnResetField.Width=145; $btnResetField.Height=42; $btnResetField.Left=380; $btnResetField.Top=115; $regPanel.Controls.Add($btnResetField)
$btnRegDone = New-Object System.Windows.Forms.Button
$btnRegDone.Text='3) ✓ ข้อมูลผู้บริจาคเสร็จ → คนถัดไป'; $btnRegDone.Width=320; $btnRegDone.Height=48; $btnRegDone.Left=545; $btnRegDone.Top=109; $btnRegDone.BackColor='Honeydew'; $btnRegDone.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold); $regPanel.Controls.Add($btnRegDone)

$lblRegHint = New-Object System.Windows.Forms.Label
$lblRegHint.Text='คำนำหน้า / เพศ / อาชีพ เป็นช่องเลือกใน LIS: ตรวจให้ตรงก่อนกดบันทึก'; $lblRegHint.AutoSize=$true; $lblRegHint.Left=0; $lblRegHint.Top=169; $lblRegHint.ForeColor='DarkRed'; $regPanel.Controls.Add($lblRegHint)

$intPanel = New-Object System.Windows.Forms.Panel
$intPanel.Left=12; $intPanel.Top=66; $intPanel.Width=1230; $intPanel.Height=205; $bottom.Controls.Add($intPanel)

$lblIntStep = New-Object System.Windows.Forms.Label
$lblIntStep.Text='ใน AI-LIS เปิดแท็บ “สัมภาษณ์ผู้บริจาคโลหิต”'; $lblIntStep.AutoSize=$true; $lblIntStep.Left=0; $lblIntStep.Top=0; $lblIntStep.ForeColor='DarkGreen'; $lblIntStep.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold); $intPanel.Controls.Add($lblIntStep)

$btnCopyDate = New-Object System.Windows.Forms.Button
$btnCopyDate.Text='คัดลอกวันที่บริจาค'; $btnCopyDate.Width=165; $btnCopyDate.Height=40; $btnCopyDate.Left=0; $btnCopyDate.Top=34; $intPanel.Controls.Add($btnCopyDate)
$btnCopyLocation = New-Object System.Windows.Forms.Button
$btnCopyLocation.Text='คัดลอกสถานที่'; $btnCopyLocation.Width=150; $btnCopyLocation.Height=40; $btnCopyLocation.Left=175; $btnCopyLocation.Top=34; $intPanel.Controls.Add($btnCopyLocation)
$btnAuto5 = New-Object System.Windows.Forms.Button
$btnAuto5.Text='1) Auto TAB 5 ค่า'; $btnAuto5.Width=180; $btnAuto5.Height=44; $btnAuto5.Left=0; $btnAuto5.Top=90; $btnAuto5.BackColor='LightSteelBlue'; $btnAuto5.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold); $intPanel.Controls.Add($btnAuto5)
$btnCopyBag = New-Object System.Windows.Forms.Button
$btnCopyBag.Text='2) คัดลอกเลขถุง'; $btnCopyBag.Width=170; $btnCopyBag.Height=44; $btnCopyBag.Left=190; $btnCopyBag.Top=90; $intPanel.Controls.Add($btnCopyBag)
$btnPasteBag = New-Object System.Windows.Forms.Button
$btnPasteBag.Text='วางเลขถุงใน 3 วิ'; $btnPasteBag.Width=175; $btnPasteBag.Height=44; $btnPasteBag.Left=370; $btnPasteBag.Top=90; $btnPasteBag.BackColor='LightYellow'; $intPanel.Controls.Add($btnPasteBag)
$btnIntDone = New-Object System.Windows.Forms.Button
$btnIntDone.Text='3) ✓ สัมภาษณ์เสร็จ → คนถัดไป'; $btnIntDone.Width=300; $btnIntDone.Height=48; $btnIntDone.Left=565; $btnIntDone.Top=87; $btnIntDone.BackColor='Honeydew'; $btnIntDone.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold); $intPanel.Controls.Add($btnIntDone)

$lblIntHint = New-Object System.Windows.Forms.Label
$lblIntHint.Text='Auto TAB: Weight → BP → Pulse → Temperature → Hb · เลือก Blood / วันที่ / สถานที่ใน LIS แล้วตรวจเลขถุงก่อนบันทึก'; $lblIntHint.AutoSize=$true; $lblIntHint.Left=0; $lblIntHint.Top=151; $lblIntHint.ForeColor='DarkRed'; $intPanel.Controls.Add($lblIntHint)

$btnResetProgress = New-Object System.Windows.Forms.Button
$btnResetProgress.Text='ล้างสถานะ ✓ ของไฟล์นี้'; $btnResetProgress.Width=175; $btnResetProgress.Height=34; $btnResetProgress.Left=1030; $btnResetProgress.Top=5; $bottom.Controls.Add($btnResetProgress)

function GetSelectedRow {
    if ($grid.SelectedRows.Count -eq 0) { return $null }
    $key = S $grid.SelectedRows[0].Cells['Key'].Value
    foreach ($r in $script:rows) { if ((RowKey $r) -eq $key) { return $r } }
    return $null
}
function CountDone($map) { return @($map.Keys).Count }
function UpdateCounts {
    $n=$script:rows.Count; $r=CountDone $script:regDone; $i=CountDone $script:interviewDone
    $lblCounts.Text="รวม $n คน · ขั้น 1: $r/$n · ขั้น 2: $i/$n"
}
function BuildGrid {
    $grid.DataSource=$null; $grid.Columns.Clear(); $grid.Rows.Clear()
    [void]$grid.Columns.Add('Key','Key'); $grid.Columns['Key'].Visible=$false
    [void]$grid.Columns.Add('Reg','ข้อมูล'); $grid.Columns['Reg'].FillWeight=45
    [void]$grid.Columns.Add('Int','สัมภาษณ์'); $grid.Columns['Int'].FillWeight=55
    [void]$grid.Columns.Add('DN','DN'); $grid.Columns['DN'].FillWeight=85
    [void]$grid.Columns.Add('DonorID','Donor ID'); $grid.Columns['DonorID'].FillWeight=75
    [void]$grid.Columns.Add('Name','ชื่อ-นามสกุล'); $grid.Columns['Name'].FillWeight=150
    [void]$grid.Columns.Add('Status','ผล'); $grid.Columns['Status'].FillWeight=75
    [void]$grid.Columns.Add('Bag','เลขถุง'); $grid.Columns['Bag'].FillWeight=90
    [void]$grid.Columns.Add('Location','สถานที่'); $grid.Columns['Location'].FillWeight=130
    foreach($r in $script:rows){
        $k=RowKey $r; $name=((S $r.Prefix)+(S $r.FirstName)+' '+(S $r.LastName)).Trim()
        $idx=$grid.Rows.Add($k, $(if($script:regDone.ContainsKey($k)){'✓'}else{'…'}), $(if($script:interviewDone.ContainsKey($k)){'✓'}else{'…'}), (S $r.DN),(S $r.Donor_ID),$name,(S $r.Screening_Status),(S $r.Bag_Number),(S $r.Location))
        if($script:regDone.ContainsKey($k) -and $script:interviewDone.ContainsKey($k)){$grid.Rows[$idx].DefaultCellStyle.BackColor=[System.Drawing.Color]::Honeydew}
    }
    UpdateCounts
}
function FindNextRegField($row,[int]$start) {
    for($i=$start;$i -lt $script:regFields.Count;$i++){
        $f=$script:regFields[$i]; $v=GetRowValue $row $f.Key
        if(-not [string]::IsNullOrWhiteSpace($v)){ return @{Index=$i;Field=$f;Value=$v} }
    }
    return $null
}
function UpdateSelected {
    $r=GetSelectedRow
    if($null -eq $r){$lblSelected.Text='ยังไม่ได้เลือกรายการ';return}
    $script:regFieldIndex=0
    $name=((S $r.Prefix)+(S $r.FirstName)+' '+(S $r.LastName)).Trim()
    $did=S $r.Donor_ID; $curNo=CurrentDonationNo $r; $lblSelected.Text="DN $(S $r.DN) · $name · Donor ID $(if($did){$did}else{'-'}) · ครั้งนี้ $(if($curNo){$curNo}else{'-'})"
    $status=S $r.Screening_Status; $reason=S $r.Reason; $bag=S $r.Bag_Number
    $lblMini.Text="ผล: $(if($status){$status}else{'-'})$(if($reason){' · '+$reason}else{''}) · Bag $(if($bag){$bag}else{'-'}) · $(GetVisitDate $r) · $(S $r.Location)"
    $hasBag=-not [string]::IsNullOrWhiteSpace($bag); $btnCopyBag.Enabled=$hasBag; $btnPasteBag.Enabled=$hasBag
    UpdateNextField
}
function UpdateNextField {
    $r=GetSelectedRow; if($null -eq $r){return}
    $n=FindNextRegField $r $script:regFieldIndex
    if($null -eq $n){$lblNext.Text='ครบช่องที่มีข้อมูลแล้ว — ตรวจใน LIS แล้วกด “ข้อมูลผู้บริจาคเสร็จ”'; return}
    $shown=$n.Value; if($n.Field.Key -eq 'ID_Card'){$shown=MaskId $shown}
    $lblNext.Text="ช่อง $($n.Index+1)/$($script:regFields.Count): $($n.Field.Label) = $shown"
}
function SelectNextIncomplete([string]$which) {
    if($grid.Rows.Count -eq 0){return}
    $start=0; if($grid.SelectedRows.Count){$start=$grid.SelectedRows[0].Index+1}
    for($pass=0;$pass -lt 2;$pass++){
        $from=if($pass -eq 0){$start}else{0}; $to=if($pass -eq 0){$grid.Rows.Count-1}else{[Math]::Min($start-1,$grid.Rows.Count-1)}
        for($i=$from;$i -le $to;$i++){
            $k=S $grid.Rows[$i].Cells['Key'].Value
            $done=if($which -eq 'registration'){$script:regDone.ContainsKey($k)}else{$script:interviewDone.ContainsKey($k)}
            if(-not $done){$grid.ClearSelection();$grid.Rows[$i].Selected=$true;$grid.FirstDisplayedScrollingRowIndex=$i;UpdateSelected;return}
        }
    }
    [System.Windows.Forms.MessageBox]::Show('ครบทุกคนในขั้นนี้แล้ว','CNMI LIS Assistant','OK','Information') | Out-Null
}
function SetPhase([string]$p) {
    if($p -eq 'interview' -and $script:rows.Count -gt 0 -and (CountDone $script:regDone) -lt $script:rows.Count){
        $left=$script:rows.Count-(CountDone $script:regDone)
        if([System.Windows.Forms.MessageBox]::Show("ขั้น 1 ยังเหลือ $left คน`r`nปกติควรลงข้อมูลผู้บริจาคให้ครบก่อน`r`n`r`nต้องการไปขั้น 2 ตอนนี้หรือไม่?",'ยังลงข้อมูลไม่ครบ','YesNo','Warning') -ne 'Yes'){return}
    }
    $script:phase=$p; $regPanel.Visible=($p -eq 'registration'); $intPanel.Visible=($p -eq 'interview')
    if($p -eq 'registration'){$btnPhase1.BackColor='LightSteelBlue';$btnPhase2.BackColor=[System.Drawing.SystemColors]::Control}else{$btnPhase2.BackColor='LightSteelBlue';$btnPhase1.BackColor=[System.Drawing.SystemColors]::Control}
    SelectNextIncomplete $p
}
function LoadCsv([string]$path) {
    try {
        if(-not (Test-Path $path)){throw 'ไม่พบไฟล์'}
        $data=@(Import-Csv -Path $path -Encoding UTF8)
        if($data.Count -eq 0){throw 'ไฟล์ไม่มีข้อมูล'}
        foreach($req in @('DN','ID_Card','FirstName','LastName')){if(-not ($data[0].PSObject.Properties.Name -contains $req)){throw "CSV ไม่มีคอลัมน์ $req"}}
        $script:rows=$data; $script:csvPath=$path; $script:progressPath=$path+'.lis-progress.json'; LoadProgress; BuildGrid
        $lblFile.Text="$(Split-Path $path -Leaf) · $($data.Count) รายการ"
        SetPhase 'registration'
    } catch { [System.Windows.Forms.MessageBox]::Show("เปิด CSV ไม่สำเร็จ: $($_.Exception.Message)",'CNMI LIS Assistant','OK','Error') | Out-Null }
}
function LatestCsv {
    $d=Join-Path $env:USERPROFILE 'Downloads'
    if(-not (Test-Path $d)){return $null}
    return Get-ChildItem -Path $d -Filter 'CNMI-LIS-*.csv' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
}
function CopyText([string]$text,[string]$label) {
    if([string]::IsNullOrWhiteSpace($text)){[System.Windows.Forms.MessageBox]::Show("ไม่มีข้อมูล: $label",'CNMI LIS Assistant','OK','Warning')|Out-Null;return $false}
    [System.Windows.Forms.Clipboard]::SetText($text); $lblMini.Text="คัดลอกแล้ว: $label = $text"; return $true
}
function PasteAfterCountdown([string]$value,[string]$label) {
    if([string]::IsNullOrWhiteSpace($value)){return}
    $form.WindowState='Minimized'; Start-Sleep -Seconds $script:countdownSeconds
    try{[System.Windows.Forms.Clipboard]::SetText($value);[System.Windows.Forms.SendKeys]::SendWait('^v')}finally{$form.WindowState='Normal';$form.Activate();$lblMini.Text="วางแล้ว: $label = $value · ตรวจช่องใน LIS"}
}

$btnNewest.Add_Click({$f=LatestCsv;if($null -eq $f){[System.Windows.Forms.MessageBox]::Show('ไม่พบ CNMI-LIS-*.csv ใน Downloads','CNMI LIS Assistant','OK','Warning')|Out-Null}else{LoadCsv $f.FullName}})
$btnOpen.Add_Click({$dlg=New-Object System.Windows.Forms.OpenFileDialog;$dlg.Filter='CNMI LIS CSV (*.csv)|*.csv|CSV (*.csv)|*.csv';if($dlg.ShowDialog() -eq 'OK'){LoadCsv $dlg.FileName}})
$btnPhase1.Add_Click({SetPhase 'registration'}); $btnPhase2.Add_Click({SetPhase 'interview'})
$grid.Add_SelectionChanged({if($script:rows.Count){UpdateSelected}})

$btnCopySearch.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};$q=GetSearchValue $r;CopyText $q.Value $q.Label|Out-Null})
$btnCopyId.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};CopyText (S $r.ID_Card) 'เลขบัตรประชาชน'|Out-Null})
$btnResetField.Add_Click({$script:regFieldIndex=0;UpdateNextField})
$btnNextField.Add_Click({
    $r=GetSelectedRow;if($null -eq $r){return};$n=FindNextRegField $r $script:regFieldIndex;if($null -eq $n){return}
    if(CopyText $n.Value $n.Field.Label){$script:regFieldIndex=$n.Index+1;UpdateNextField}
})
$btnPasteNext.Add_Click({
    $r=GetSelectedRow;if($null -eq $r){return};$n=FindNextRegField $r $script:regFieldIndex;if($null -eq $n){return}
    if([System.Windows.Forms.MessageBox]::Show("คลิกช่อง “$($n.Field.Label)” ใน LIS`r`nระบบจะวางค่าใน $($script:countdownSeconds) วินาที`r`n`r`nดำเนินการหรือไม่?",'วางช่องถัดไป','YesNo','Information') -eq 'Yes'){
        PasteAfterCountdown $n.Value $n.Field.Label;$script:regFieldIndex=$n.Index+1;UpdateNextField
    }
})
$btnRegDone.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};$k=RowKey $r;$script:regDone[$k]=$true;SaveProgress;BuildGrid;SelectNextIncomplete 'registration'})

$btnCopyDate.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};CopyText (GetVisitDate $r) 'วันที่บริจาค'|Out-Null})
$btnCopyLocation.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};CopyText (S $r.Location) 'สถานที่รับบริจาค'|Out-Null})
$btnAuto5.Add_Click({
    $r=GetSelectedRow;if($null -eq $r){return}
    $vals=@();foreach($f in $script:autoInterviewFields){$vals+=@{Field=$f;Value=(GetRowValue $r $f)}}
    $missing=@($vals|Where-Object{[string]::IsNullOrWhiteSpace($_.Value)}|ForEach-Object{$_.Field})
    if($missing.Count){if([System.Windows.Forms.MessageBox]::Show("มีค่าว่าง: $($missing -join ', ')`r`nยังต้องการ Auto TAB หรือไม่?",'มีค่าว่าง','YesNo','Warning') -ne 'Yes'){return}}
    if([System.Windows.Forms.MessageBox]::Show("1. เปิดแท็บ สัมภาษณ์ผู้บริจาคโลหิต`r`n2. คลิกช่อง น้ำหนัก`r`n3. กด Yes แล้วกลับไปคลิกช่องน้ำหนักภายใน $($script:countdownSeconds) วินาที`r`n`r`nระบบจะใส่ Weight → BP → Pulse → Temperature → Hb",'Auto TAB 5 ค่า','YesNo','Warning') -ne 'Yes'){return}
    $form.WindowState='Minimized';Start-Sleep -Seconds $script:countdownSeconds
    try{
        for($i=0;$i -lt $vals.Count;$i++){
            [System.Windows.Forms.Clipboard]::SetText([string]$vals[$i].Value);[System.Windows.Forms.SendKeys]::SendWait('^v');Start-Sleep -Milliseconds $script:delayMs
            if($i -lt $vals.Count-1){[System.Windows.Forms.SendKeys]::SendWait('{TAB}');Start-Sleep -Milliseconds $script:delayMs}
        }
    }catch{[System.Windows.Forms.MessageBox]::Show("Auto TAB หยุด: $($_.Exception.Message)",'CNMI LIS Assistant','OK','Error')|Out-Null}finally{$form.WindowState='Normal';$form.Activate();$lblMini.Text='ใส่ 5 ค่าแล้ว — ตรวจทุกช่อง เลือก Blood แล้วใส่ Bag Number'}
})
$btnCopyBag.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};CopyText (S $r.Bag_Number) 'Bag Number'|Out-Null})
$btnPasteBag.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};$bag=S $r.Bag_Number;if(-not $bag){return};if([System.Windows.Forms.MessageBox]::Show("คลิกช่องหมายเลขถุงใน LIS`r`nระบบจะวาง $bag ใน $($script:countdownSeconds) วินาที",'วางเลขถุง','YesNo','Warning') -eq 'Yes'){PasteAfterCountdown $bag 'Bag Number'}})
$btnIntDone.Add_Click({$r=GetSelectedRow;if($null -eq $r){return};$k=RowKey $r;$script:interviewDone[$k]=$true;SaveProgress;BuildGrid;SelectNextIncomplete 'interview'})
$btnResetProgress.Add_Click({if($script:rows.Count -eq 0){return};if([System.Windows.Forms.MessageBox]::Show('ล้างเครื่องหมาย ✓ ทั้งขั้น 1 และขั้น 2 ของไฟล์นี้หรือไม่?','ยืนยัน','YesNo','Warning') -eq 'Yes'){$script:regDone=@{};$script:interviewDone=@{};SaveProgress;BuildGrid;SetPhase 'registration'}})

SetPhase 'registration'
$f=LatestCsv
if($null -ne $f){$lblFile.Text="พบไฟล์ล่าสุด: $($f.Name) — กด “เปิด CSV ล่าสุดใน Downloads”"}
[void]$form.ShowDialog()
