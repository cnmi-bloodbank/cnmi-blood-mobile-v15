@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CNMI-LIS-Assistant-Easy.ps1"
if errorlevel 1 (
  echo.
  echo LIS Assistant could not start. Please send a screenshot of this window to the unit admin.
  pause
)
