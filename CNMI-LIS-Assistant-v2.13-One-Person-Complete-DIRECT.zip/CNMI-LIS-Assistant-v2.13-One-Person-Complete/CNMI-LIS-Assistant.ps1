﻿# CNMI LIS Assistant v2.13 One Person Complete Workflow
# Local-only helper. It mimics staff entry using paste + TAB. Staff verifies and saves in AI-LIS themselves.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$rows = @()
$regDone = @{}
$donDone = @{}
$delayMs = 380
$slowDelayMs = 700
$lockedKey = ''
$lockedIndex = -1
$lockedStep = 0
$suppressSelection = $false

function Row-Value($row, [string]$field) {
    if ($null -eq $row) { return '' }
    $prop = $row.PSObject.Properties[$field]
    if ($null -eq $prop -or $null -eq $prop.Value) { return '' }
    return ([string]$prop.Value).Trim()
}
function Row-Key($row) {
    $dn = Row-Value $row 'DN'
    if ($dn) { return $dn }
    return ((Row-Value $row 'ID_Card') + '|' + (Row-Value $row 'FirstName') + '|' + (Row-Value $row 'LastName'))
}
function Display-Name($row) {
    return (((Row-Value $row 'Prefix') + (Row-Value $row 'FirstName') + ' ' + (Row-Value $row 'LastName')).Trim())
}
function Show-Value([string]$v) {
    if ([string]::IsNullOrWhiteSpace($v)) { return '-' }
    return $v
}
function Normalize-BagKey([string]$v) {
    return (([string]$v).Trim().ToUpper() -replace '[^A-Z0-9]','')
}
function Is-Passed($row) {
    return ((Row-Value $row 'Screening_Status') -eq 'ผ่าน')
}
function Is-Failed($row) {
    return ((Row-Value $row 'Screening_Status') -eq 'ไม่ผ่าน')
}
function Has-ScreeningResult($row) {
    $s = Row-Value $row 'Screening_Status'
    return ($s -eq 'ผ่าน' -or $s -eq 'ไม่ผ่าน')
}
function Safety-Text($row) {
    $status=Row-Value $row 'Screening_Status'
    $bag=Row-Value $row 'Bag_Number'
    $lot=Row-Value $row 'Bag_Lot'
    if($status -eq 'ไม่ผ่าน' -and -not [string]::IsNullOrWhiteSpace($bag)){ return 'ERROR: ไม่ผ่านแต่มี Bag' }
    if($status -eq 'ผ่าน' -and [string]::IsNullOrWhiteSpace($bag)){ return 'ERROR: ผ่านแต่ไม่มี Bag' }
    if($status -eq 'ผ่าน' -and [string]::IsNullOrWhiteSpace($lot)){ return 'รอ Bag Lot' }
    return 'OK'
}
function Preferred-SearchId($row) {
    $donorId=Row-Value $row 'Donor_ID'
    if(-not [string]::IsNullOrWhiteSpace($donorId)){ return $donorId }
    return (Row-Value $row 'ID_Card')
}
function Normalize-Prefix([string]$v) {
    $s = $v.Trim()
    if ($s -eq 'นางสาว' -or $s -eq 'น.ส') { return 'น.ส.' }
    if ($s -eq 'น.ส.') { return 'น.ส.' }
    return $s
}
function Normalize-BirthdateForLis([string]$v) {
    # AI-LIS birthdate textbox is a masked field and inserts '-' separators itself.
    # Therefore send digits only as DDMMYYYY (B.E.), e.g. 9/6/2541 -> 09062541.
    $s = ([string]$v).Trim()
    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    if ($s -match '^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$') {
        $d=[int]$matches[1]; $m=[int]$matches[2]; $y=[int]$matches[3]
        if ($d -ge 1 -and $d -le 31 -and $m -ge 1 -and $m -le 12) {
            return ('{0:D2}{1:D2}{2:D4}' -f $d,$m,$y)
        }
    }
    $digits = ($s -replace '[^0-9]','')
    if ($digits.Length -eq 8) { return $digits }
    return ''
}
function Normalize-OccupationForLis([string]$v) {
    # Blood Mobile uses category labels with '/' but AI-LIS occupation lookup uses spaces.
    # Examples: "พนักงานบริษัท/รับจ้าง" -> "พนักงานบริษัท รับจ้าง"
    # For Rama personnel / Other, use the entered detail because AI-LIS has detailed occupations.
    $s = ([string]$v).Trim()
    if ([string]::IsNullOrWhiteSpace($s)) { return '' }

    if ($s -match '^บุคลากรใน\s*ร\.พ\.รามาฯ\s*[:：]\s*(.+)$') {
        $s = $matches[1].Trim()
    } elseif ($s -match '^อื่นๆ\s*[:：]\s*(.+)$') {
        $s = $matches[1].Trim()
    }

    $s = $s -replace '\s*/\s*', ' '
    $s = $s -replace '\s+', ' '
    return $s.Trim()
}
function Select-LisOccupation([string]$value, [int]$waitMs) {
    $s = Normalize-OccupationForLis $value
    if ([string]::IsNullOrWhiteSpace($s)) { return }

    # AI-LIS occupation is an editable lookup/dropdown, not a plain textbox.
    # Pasting alone can show text but the value is discarded on TAB unless the lookup item is committed.
    Paste-Value $s ([Math]::Max($waitMs, 500))
    Start-Sleep -Milliseconds 350
    [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
    Start-Sleep -Milliseconds ([Math]::Max($waitMs, 500))
}


function Select-LisBloodGroup([string]$value, [int]$waitMs) {
    $s = ([string]$value).Trim().ToUpperInvariant()
    if ([string]::IsNullOrWhiteSpace($s) -or $s -eq '-') { return }
    if ($s -notin @('A','B','AB','O')) { throw "Blood Group ไม่ถูกต้อง: $s" }

    # AI-LIS Blood Group is a lookup/dropdown. Clipboard paste can appear briefly but is not committed.
    # Send real keystrokes, then ENTER to commit the selected item before continuing TAB navigation.
    Start-Sleep -Milliseconds 200
    [System.Windows.Forms.SendKeys]::SendWait($s)
    Start-Sleep -Milliseconds ([Math]::Max($waitMs, 500))
    [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
    Start-Sleep -Milliseconds ([Math]::Max($waitMs, 500))
}

function Paste-Value([string]$value, [int]$waitMs) {
    if (-not [string]::IsNullOrWhiteSpace($value)) {
        [System.Windows.Forms.SendKeys]::SendWait('^a')
        Start-Sleep -Milliseconds 80
        [System.Windows.Forms.Clipboard]::SetText([string]$value)
        [System.Windows.Forms.SendKeys]::SendWait('^v')
        Start-Sleep -Milliseconds $waitMs
    }
}
function Send-Tab([int]$count, [int]$waitMs) {
    for ($i=0; $i -lt $count; $i++) {
        [System.Windows.Forms.SendKeys]::SendWait('{TAB}')
        Start-Sleep -Milliseconds $waitMs
    }
}
function Get-Selected {
    if ($grid.SelectedRows.Count -eq 0) { return $null }
    return $grid.SelectedRows[0].Tag
}
function Safe-AutoStart([string]$title, [string]$message) {
    $ans = [System.Windows.Forms.MessageBox]::Show($message,$title,'YesNo','Information')
    if ($ans -ne 'Yes') { return $false }
    $form.WindowState='Minimized'
    Start-Sleep -Seconds 4
    return $true
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'CNMI LIS Assistant v2.13 One Person Complete - Local Only'
$form.Size = New-Object System.Drawing.Size(1380,900)
$form.MinimumSize = New-Object System.Drawing.Size(1180,820)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)

$layout = New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock='Fill'; $layout.ColumnCount=1; $layout.RowCount=3
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,110)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,405)))
$form.Controls.Add($layout)

# ---------- Top ----------
$top = New-Object System.Windows.Forms.Panel
$top.Dock='Fill'; $top.Padding='10,8,10,6'
$layout.Controls.Add($top,0,0)

$btnOpen = New-Object System.Windows.Forms.Button
$btnOpen.Text='1) เปิดไฟล์ CNMI-LIS-*.csv'; $btnOpen.Left=10; $btnOpen.Top=8; $btnOpen.Width=220; $btnOpen.Height=34
$top.Controls.Add($btnOpen)
$lblFile = New-Object System.Windows.Forms.Label
$lblFile.Text='ยังไม่ได้เลือกไฟล์'; $lblFile.Left=242; $lblFile.Top=16; $lblFile.AutoSize=$true
$top.Controls.Add($lblFile)

$lblStep = New-Object System.Windows.Forms.Label
$lblStep.Text='ขั้นตอน'; $lblStep.Left=10; $lblStep.Top=52; $lblStep.AutoSize=$true
$top.Controls.Add($lblStep)
$cmbStep = New-Object System.Windows.Forms.ComboBox
$cmbStep.Left=70; $cmbStep.Top=47; $cmbStep.Width=280; $cmbStep.DropDownStyle='DropDownList'
[void]$cmbStep.Items.Add('1) ข้อมูลผู้บริจาค')
[void]$cmbStep.Items.Add('2) สัมภาษณ์ / ผลคัดกรอง')
$cmbStep.SelectedIndex=0
$top.Controls.Add($cmbStep)
$lblStep.Visible=$false
$cmbStep.Visible=$false

$lblProgress = New-Object System.Windows.Forms.Label
$lblProgress.Text='ส่วน 1: 0/0 | ส่วน 2: 0/0 | Complete: 0/0'; $lblProgress.Left=10; $lblProgress.Top=53; $lblProgress.AutoSize=$true
$lblProgress.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
$top.Controls.Add($lblProgress)

$lblTopHint = New-Object System.Windows.Forms.Label
$lblTopHint.Text='ทำทีละคนให้จบ: ส่วนที่ 1 → ส่วนที่ 2 → ✓ Complete → คนถัดไป | ระหว่างทำเปลี่ยนคนไม่ได้'
$lblTopHint.Left=10; $lblTopHint.Top=82; $lblTopHint.AutoSize=$true; $lblTopHint.ForeColor='DarkBlue'
$top.Controls.Add($lblTopHint)

# ---------- Grid ----------
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock='Fill'; $grid.ReadOnly=$true; $grid.SelectionMode='FullRowSelect'; $grid.MultiSelect=$false
$grid.AllowUserToAddRows=$false; $grid.AllowUserToDeleteRows=$false; $grid.AllowUserToResizeRows=$false
$grid.RowHeadersVisible=$false; $grid.AutoGenerateColumns=$false; $grid.BackgroundColor='White'; $grid.BorderStyle='FixedSingle'
function Add-Col([string]$name,[string]$header,[int]$width) {
    $c=New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $c.Name=$name; $c.HeaderText=$header; $c.Width=$width; $c.SortMode='NotSortable'
    [void]$grid.Columns.Add($c)
}
Add-Col 'No' 'ลำดับ' 55
Add-Col 'DN' 'DN' 145
Add-Col 'DonorID' 'Donor ID' 110
Add-Col 'Name' 'ชื่อ-นามสกุล' 240
Add-Col 'Status' 'ผล' 70
Add-Col 'Bag' 'Bag Number' 125
Add-Col 'BagLot' 'Bag Lot' 125
Add-Col 'Safety' 'Safety' 150
Add-Col 'Reg' 'ส่วน 1' 65
Add-Col 'Don' 'ส่วน 2' 65
$layout.Controls.Add($grid,0,1)

# ---------- Bottom ----------
$bottom = New-Object System.Windows.Forms.Panel
$bottom.Dock='Fill'; $bottom.Padding='10,6,10,8'
$layout.Controls.Add($bottom,0,2)

$lblSelected = New-Object System.Windows.Forms.Label
$lblSelected.Text='ยังไม่ได้เลือกรายการ'; $lblSelected.Left=10; $lblSelected.Top=2; $lblSelected.Width=1320; $lblSelected.Height=42
$lblSelected.Font=New-Object System.Drawing.Font('Segoe UI',20,[System.Drawing.FontStyle]::Bold)
$lblSelected.ForeColor='Navy'
$bottom.Controls.Add($lblSelected)
$lblSummary = New-Object System.Windows.Forms.Label
$lblSummary.Text=''; $lblSummary.Left=10; $lblSummary.Top=46; $lblSummary.Width=1320; $lblSummary.Height=24; $lblSummary.ForeColor='DarkSlateBlue'
$bottom.Controls.Add($lblSummary)
$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text=''; $lblStatus.Left=10; $lblStatus.Top=70; $lblStatus.Width=1320; $lblStatus.Height=24; $lblStatus.ForeColor='DarkGreen'
$bottom.Controls.Add($lblStatus)

# Step 1 panel
$p1 = New-Object System.Windows.Forms.Panel
$p1.Left=0; $p1.Top=96; $p1.Width=1340; $p1.Height=300
$bottom.Controls.Add($p1)

$lab1 = New-Object System.Windows.Forms.Label
$lab1.Text='คนนี้ — ส่วนที่ 1: ค้น AI-LIS → ยืนยันชื่อ → Auto ข้อมูลผู้บริจาค'
$lab1.Left=10; $lab1.Top=4; $lab1.AutoSize=$true; $lab1.ForeColor='DarkBlue'; $lab1.Font=New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
$p1.Controls.Add($lab1)

$btnSearchId = New-Object System.Windows.Forms.Button
$btnSearchId.Text='1) ส่ง Donor ID / เลขบัตร ไปช่องค้นหา AI-LIS'
$btnSearchId.Left=10; $btnSearchId.Top=34; $btnSearchId.Width=430; $btnSearchId.Height=42; $btnSearchId.BackColor='LightCyan'; $btnSearchId.Enabled=$false
$p1.Controls.Add($btnSearchId)

$chkIdentity = New-Object System.Windows.Forms.CheckBox
$chkIdentity.Text='2) ✓ ชื่อที่เปิดใน AI-LIS ตรงกับคนตัวใหญ่ด้านบนแล้ว'
$chkIdentity.Left=465; $chkIdentity.Top=43; $chkIdentity.Width=500; $chkIdentity.Height=28; $chkIdentity.Enabled=$false
$chkIdentity.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
$p1.Controls.Add($chkIdentity)

$btnAuto1 = New-Object System.Windows.Forms.Button
$btnAuto1.Text='3) Auto ส่วนที่ 1 — คำนำหน้า → ... → อาชีพ → โทรศัพท์'
$btnAuto1.Left=10; $btnAuto1.Top=86; $btnAuto1.Width=650; $btnAuto1.Height=48; $btnAuto1.BackColor='LightSteelBlue'; $btnAuto1.Enabled=$false
$p1.Controls.Add($btnAuto1)

$btnDone1 = New-Object System.Windows.Forms.Button
$btnDone1.Text='✓ ส่วนที่ 1 บันทึกแล้ว → ไปส่วนที่ 2 ของคนเดิม'; $btnDone1.Left=720; $btnDone1.Top=86; $btnDone1.Width=590; $btnDone1.Height=48; $btnDone1.BackColor='PaleGreen'; $btnDone1.Enabled=$false
$p1.Controls.Add($btnDone1)

$lblSeq1 = New-Object System.Windows.Forms.Label
$lblSeq1.Text='คำนำหน้า → Tab×2 → ชื่อ → นามสกุล → วันเกิด → เลขบัตร → Tab×5 → ที่อยู่ → ตำบล → อำเภอ → จังหวัด → รหัสไปรษณีย์ → อาชีพ → โทรศัพท์ → จบ'
$lblSeq1.Left=10; $lblSeq1.Top=146; $lblSeq1.Width=1300; $lblSeq1.Height=28; $lblSeq1.ForeColor='DarkGreen'
$p1.Controls.Add($lblSeq1)
$lblManual = New-Object System.Windows.Forms.Label
$lblManual.Text='เพศ: ให้ AI-LIS จัดการ/เจ้าหน้าที่ตรวจเอง  |  Email: ไม่กรอกอัตโนมัติ  |  อาชีพ: แปลงชื่อให้ตรง AI-LIS + Enter ยืนยันตัวเลือกอัตโนมัติ'
$lblManual.Left=10; $lblManual.Top=174; $lblManual.Width=1300; $lblManual.Height=25; $lblManual.ForeColor='DarkOrange'
$p1.Controls.Add($lblManual)
$lblBlank1 = New-Object System.Windows.Forms.Label
$lblBlank1.Text='เมื่อเริ่มค้น AI-LIS คนนี้จะถูกล็อกจนทำส่วนที่ 1 + ส่วนที่ 2 เสร็จทั้งคน'
$lblBlank1.Left=10; $lblBlank1.Top=202; $lblBlank1.Width=1300; $lblBlank1.Height=25; $lblBlank1.ForeColor='DarkRed'; $lblBlank1.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
$p1.Controls.Add($lblBlank1)

# Step 2 panel
$p2 = New-Object System.Windows.Forms.Panel
$p2.Left=0; $p2.Top=96; $p2.Width=1340; $p2.Height=300; $p2.Visible=$false
$bottom.Controls.Add($p2)
$lblP2 = New-Object System.Windows.Forms.Label
$lblP2.Text='คนเดิม — ส่วนที่ 2: Auto ผลคัดกรองให้จบก่อนเปลี่ยนคน'
$lblP2.Left=10; $lblP2.Top=4; $lblP2.AutoSize=$true; $lblP2.ForeColor='DarkBlue'; $lblP2.Font=New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
$p2.Controls.Add($lblP2)

$txtValues = New-Object System.Windows.Forms.Label
$txtValues.Text=''; $txtValues.Left=10; $txtValues.Top=34; $txtValues.Width=1300; $txtValues.Height=26
$p2.Controls.Add($txtValues)

$lblBagVerify = New-Object System.Windows.Forms.Label
$lblBagVerify.Text='1) ยิง Barcode ถุงเพื่อยืนยัน:'; $lblBagVerify.Left=10; $lblBagVerify.Top=70; $lblBagVerify.Width=220; $lblBagVerify.Height=26
$p2.Controls.Add($lblBagVerify)
$txtBagVerify = New-Object System.Windows.Forms.TextBox
$txtBagVerify.Left=235; $txtBagVerify.Top=66; $txtBagVerify.Width=260; $txtBagVerify.Height=30; $txtBagVerify.Enabled=$false
$txtBagVerify.Font=New-Object System.Drawing.Font('Consolas',12,[System.Drawing.FontStyle]::Bold)
$p2.Controls.Add($txtBagVerify)
$lblBagVerifyStatus = New-Object System.Windows.Forms.Label
$lblBagVerifyStatus.Text=''; $lblBagVerifyStatus.Left=510; $lblBagVerifyStatus.Top=70; $lblBagVerifyStatus.Width=420; $lblBagVerifyStatus.Height=26
$p2.Controls.Add($lblBagVerifyStatus)

$btnAuto2 = New-Object System.Windows.Forms.Button
$btnAuto2.Text='2) Auto ส่วนที่ 2'; $btnAuto2.Left=10; $btnAuto2.Top=112; $btnAuto2.Width=650; $btnAuto2.Height=48; $btnAuto2.BackColor='LightSteelBlue'; $btnAuto2.Enabled=$false
$p2.Controls.Add($btnAuto2)
$btnDone2 = New-Object System.Windows.Forms.Button
$btnDone2.Text='✓ เสร็จทั้งคนนี้ → คนถัดไป'; $btnDone2.Left=720; $btnDone2.Top=112; $btnDone2.Width=590; $btnDone2.Height=48; $btnDone2.BackColor='PaleGreen'; $btnDone2.Enabled=$false
$p2.Controls.Add($btnDone2)
$lblSeq2 = New-Object System.Windows.Forms.Label
$lblSeq2.Text='ผ่าน: Weight → BP → Pulse → Temperature → Hb → Bag → V → Group → Bag Lot | ไม่ผ่าน: Weight → BP → Pulse → Temperature → Hb → จบ'
$lblSeq2.Left=10; $lblSeq2.Top=172; $lblSeq2.Width=1300; $lblSeq2.Height=26; $lblSeq2.ForeColor='DarkGreen'
$p2.Controls.Add($lblSeq2)
$lblBlank = New-Object System.Windows.Forms.Label
$lblBlank.Text='ผ่าน: ต้องยิงถุงให้ตรง Expected Bag ก่อน Auto | ไม่ผ่าน: ไม่ต้องมี Bag / Group / Bag Lot และจะหยุดทันทีหลัง Hb'
$lblBlank.Left=10; $lblBlank.Top=202; $lblBlank.Width=1300; $lblBlank.Height=26; $lblBlank.ForeColor='DarkRed'; $lblBlank.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
$p2.Controls.Add($lblBlank)

function Populate-Grid {
    $grid.Rows.Clear()
    for($i=0;$i -lt $rows.Count;$i++) {
        $r=$rows[$i]; $key=Row-Key $r
        $reg=if($regDone.ContainsKey($key)){'✓'}else{'รอ'}
        $don=if(-not (Has-ScreeningResult $r)){'—'}elseif($donDone.ContainsKey($key)){'✓'}else{'รอ'}
        $safety=Safety-Text $r
        $idx=$grid.Rows.Add(($i+1),(Row-Value $r 'DN'),(Row-Value $r 'Donor_ID'),(Display-Name $r),(Row-Value $r 'Screening_Status'),(Row-Value $r 'Bag_Number'),(Row-Value $r 'Bag_Lot'),$safety,$reg,$don)
        $grid.Rows[$idx].Tag=$r
        if($safety.StartsWith('ERROR')) { $grid.Rows[$idx].DefaultCellStyle.BackColor='MistyRose' }
        elseif($safety -eq 'รอ Bag Lot') { $grid.Rows[$idx].DefaultCellStyle.BackColor='LemonChiffon' }
    }
    if($grid.Rows.Count -gt 0) {
        $script:suppressSelection=$true
        $grid.ClearSelection()
        $grid.CurrentCell=$grid.Rows[0].Cells['DN']
        $grid.Rows[0].Selected=$true
        $grid.FirstDisplayedScrollingRowIndex=0
        $script:suppressSelection=$false
    }
}
function Update-Progress {
    $screenedCount=@($rows | Where-Object { Has-ScreeningResult $_ }).Count
    $completeCount=0
    foreach($r in $rows){
        $key=Row-Key $r
        if($regDone.ContainsKey($key) -and (Has-ScreeningResult $r) -and $donDone.ContainsKey($key)){ $completeCount++ }
    }
    $lblProgress.Text="ส่วน 1: $($regDone.Count)/$($rows.Count) | ส่วน 2: $($donDone.Count)/$screenedCount | Complete: $completeCount/$screenedCount"
}
function Update-Grid-Status {
    foreach($gr in $grid.Rows) {
        if($null -eq $gr.Tag){continue}; $key=Row-Key $gr.Tag
        $hasScreen=Has-ScreeningResult $gr.Tag
        $regOk=$regDone.ContainsKey($key)
        $donOk=$donDone.ContainsKey($key)
        $complete=($regOk -and $hasScreen -and $donOk)
        $gr.Cells['Reg'].Value=if($regOk){'✓'}else{'รอ'}
        $gr.Cells['Don'].Value=if(-not $hasScreen){'—'}elseif($donOk){'✓'}else{'รอ'}
        if($complete){
            $gr.Cells['Safety'].Value='✓ Complete'
            $gr.DefaultCellStyle.BackColor='PaleGreen'
            $gr.DefaultCellStyle.ForeColor='DarkGreen'
        } else {
            $safety=Safety-Text $gr.Tag
            $gr.Cells['Safety'].Value=$safety
            $gr.DefaultCellStyle.ForeColor='Black'
            if($safety.StartsWith('ERROR')){$gr.DefaultCellStyle.BackColor='MistyRose'}
            elseif($safety -eq 'รอ Bag Lot'){$gr.DefaultCellStyle.BackColor='LemonChiffon'}
            else{$gr.DefaultCellStyle.BackColor='White'}
        }
    }
}
function Set-RowLock($r,[int]$step) {
    if([string]::IsNullOrWhiteSpace($lockedKey)){
        $script:lockedKey=Row-Key $r
        $script:lockedIndex=$grid.SelectedRows[0].Index
    }
    $script:lockedStep=$step
    $cmbStep.Enabled=$false
    $btnOpen.Enabled=$false
    $grid.DefaultCellStyle.SelectionBackColor='DarkOrange'
    $lblStatus.Text="🔒 กำลังทำคนนี้: $(Display-Name $r) · DN $(Row-Value $r 'DN') · ต้องจบทั้งส่วน 1 + 2 ก่อนเปลี่ยนคน"
    $lblStatus.ForeColor='DarkRed'
}
function Clear-RowLock {
    $script:lockedKey=''
    $script:lockedIndex=-1
    $script:lockedStep=0
    $cmbStep.Enabled=$true
    $btnOpen.Enabled=$true
    $grid.DefaultCellStyle.SelectionBackColor=[System.Drawing.SystemColors]::Highlight
    $lblStatus.ForeColor='DarkGreen'
    $chkIdentity.Checked=$false
    $chkIdentity.Enabled=$false
    $txtBagVerify.Text=''
    $p1.Visible=$true
    $p2.Visible=$false
}
function Update-BagVerification {
    $r=Get-Selected
    if($null -eq $r){return}
    $status=Row-Value $r 'Screening_Status'
    $safety=Safety-Text $r

    if($status -eq 'ไม่ผ่าน'){
        $txtBagVerify.Enabled=$false
        $txtBagVerify.Text=''
        if($safety.StartsWith('ERROR')){
            $lblBagVerifyStatus.Text=$safety
            $lblBagVerifyStatus.ForeColor='Red'
            $btnAuto2.Enabled=$false
        } else {
            $lblBagVerifyStatus.Text='✓ ไม่ผ่าน: ไม่ต้องยิง Barcode ถุง · Auto เฉพาะ 5 ค่า'
            $lblBagVerifyStatus.ForeColor='DarkGreen'
            $btnAuto2.Enabled=($lockedStep -eq 20)
        }
        return
    }

    if($status -ne 'ผ่าน'){
        $txtBagVerify.Enabled=$false
        $lblBagVerifyStatus.Text='⛔ ยังไม่มีผลคัดกรอง ผ่าน/ไม่ผ่าน'
        $lblBagVerifyStatus.ForeColor='DarkRed'
        $btnAuto2.Enabled=$false
        return
    }

    $expected=Normalize-BagKey (Row-Value $r 'Bag_Number')
    $scanned=Normalize-BagKey $txtBagVerify.Text
    $eligible=-not [string]::IsNullOrWhiteSpace((Row-Value $r 'Bag_Number')) -and -not [string]::IsNullOrWhiteSpace((Row-Value $r 'Bag_Lot')) -and ($safety -eq 'OK')
    if(-not $eligible){
        $lblBagVerifyStatus.Text='⛔ ผ่าน: ต้องมี Bag + Bag Lot ก่อน Auto'
        $lblBagVerifyStatus.ForeColor='DarkRed'; $btnAuto2.Enabled=$false; return
    }
    if([string]::IsNullOrWhiteSpace($scanned)){
        $lblBagVerifyStatus.Text="Expected Bag: $(Row-Value $r 'Bag_Number')"
        $lblBagVerifyStatus.ForeColor='DarkBlue'; $btnAuto2.Enabled=$false; return
    }
    if($scanned -eq $expected){
        $lblBagVerifyStatus.Text='✓ Barcode ถุงตรงกับคนนี้'
        $lblBagVerifyStatus.ForeColor='DarkGreen'; $btnAuto2.Enabled=($lockedStep -eq 20); return
    }
    $lblBagVerifyStatus.Text="✗ ถุงไม่ตรง! Expected $(Row-Value $r 'Bag_Number')"
    $lblBagVerifyStatus.ForeColor='Red'; $btnAuto2.Enabled=$false
}
function Refresh-Selected {
    $r=Get-Selected
    if($null -eq $r){return}
    $safety=Safety-Text $r
    $status=Row-Value $r 'Screening_Status'
    $key=Row-Key $r
    $part1Done=$regDone.ContainsKey($key)
    $part2Done=$donDone.ContainsKey($key)
    $stateText=if($part1Done -and $part2Done){'✓ Complete'}elseif($part1Done){'ส่วนที่ 1 ✓ | ส่วนที่ 2 รอดำเนินการ'}else{'ส่วนที่ 1 รอดำเนินการ | ส่วนที่ 2 รอดำเนินการ'}
    $lblSelected.Text="$(Display-Name $r)   |   DN $(Row-Value $r 'DN')   |   Unit $(Show-Value (Row-Value $r 'Bag_Number'))   |   $(Show-Value $status)"
    $lblSummary.Text="$stateText | Donor ID $(Show-Value (Row-Value $r 'Donor_ID')) | ID Card $(Show-Value (Row-Value $r 'ID_Card')) | Group $(Show-Value (Row-Value $r 'Blood_Group')) | Bag Lot $(Show-Value (Row-Value $r 'Bag_Lot'))"
    $txtValues.Text="Weight $(Show-Value (Row-Value $r 'Weight')) | BP $(Show-Value (Row-Value $r 'BP')) | Pulse $(Show-Value (Row-Value $r 'Pulse')) | Temp $(Show-Value (Row-Value $r 'Temperature')) | Hb $(Show-Value (Row-Value $r 'Hb')) | Bag $(Show-Value (Row-Value $r 'Bag_Number')) | Group $(Show-Value (Row-Value $r 'Blood_Group')) | Bag Lot $(Show-Value (Row-Value $r 'Bag_Lot'))"

    $p1.Visible=($lockedStep -notin @(20,21))
    $p2.Visible=($lockedStep -in @(20,21))
    $btnSearchId.Enabled=($lockedStep -eq 0)
    $chkIdentity.Enabled=($lockedStep -eq 10)
    $btnAuto1.Enabled=($lockedStep -eq 10 -and $chkIdentity.Checked)
    $btnDone1.Enabled=($lockedStep -eq 11)
    $btnDone2.Enabled=($lockedStep -eq 21)

    if($status -eq 'ผ่าน'){
        $lblP2.Text='คนเดิม — ส่วนที่ 2 (ผ่าน): ยิงถุงยืนยัน → Auto → Complete'
        $btnAuto2.Text='Auto ส่วนที่ 2 — 5 ค่า + Bag + V + Group + Bag Lot'
        $lblSeq2.Text='Weight → BP → Pulse → Temperature → Hb → Bag → Tab×2 → V → Tab×3 → Group + Enter → Tab×4 → Bag Lot → จบ'
        $lblBlank.Text='ต้องยิง Barcode ถุงให้ตรง Expected Bag ก่อน Auto เพื่อป้องกันคนกับถุงสลับกัน'
        $txtBagVerify.Enabled=($lockedStep -eq 20 -and $safety -eq 'OK')
    } elseif($status -eq 'ไม่ผ่าน'){
        $lblP2.Text='คนเดิม — ส่วนที่ 2 (ไม่ผ่าน): Auto 5 ค่าแล้ว Complete'
        $btnAuto2.Text='Auto ส่วนที่ 2 — 5 ค่า (ไม่ผ่าน)'
        $lblSeq2.Text='Weight → BP → Pulse → Temperature → Hb → จบทันที'
        $lblBlank.Text='ไม่ผ่าน: ไม่ส่ง Bag Number / V / Group / Bag Lot และไม่ต้องยิง Barcode ถุง'
        $txtBagVerify.Enabled=$false
        $txtBagVerify.Text=''
    } else {
        $lblP2.Text='คนเดิม — ส่วนที่ 2: ยังไม่มีผลคัดกรอง'
        $btnAuto2.Text='Auto ส่วนที่ 2'
        $lblSeq2.Text='ต้องมีผล ผ่าน หรือ ไม่ผ่าน ก่อน'
        $lblBlank.Text=''
        $txtBagVerify.Enabled=$false
        $txtBagVerify.Text=''
    }

    Update-BagVerification
    if($safety.StartsWith('ERROR')){$lblStatus.Text=$safety; $lblStatus.ForeColor='Red'}
    elseif($safety -eq 'รอ Bag Lot'){$lblStatus.Text='⚠ ผ่านและมี Bag แล้ว แต่ยังไม่มี Bag Lot — ส่วนที่ 2 จะไม่เปิด'; $lblStatus.ForeColor='DarkOrange'}
    elseif($lockedStep -eq 0){$lblStatus.Text='เลือกคนแล้วกดส่ง ID เพื่อเริ่ม Workflow คนนี้'; $lblStatus.ForeColor='DarkGreen'}
}
function Select-Next {
    if($grid.Rows.Count -eq 0){return}
    $i=0
    if($grid.SelectedRows.Count -gt 0){$i=$grid.SelectedRows[0].Index+1}
    if($i -ge $grid.Rows.Count){$i=0}
    $script:suppressSelection=$true
    $grid.ClearSelection(); $grid.CurrentCell=$grid.Rows[$i].Cells['DN']; $grid.Rows[$i].Selected=$true
    $grid.FirstDisplayedScrollingRowIndex=$i
    $script:suppressSelection=$false
    $chkIdentity.Checked=$false
    $txtBagVerify.Text=''
    Refresh-Selected
}
$btnOpen.Add_Click({
    $dlg=New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter='CNMI LIS CSV (*.csv)|*.csv|CSV files (*.csv)|*.csv'
    if($dlg.ShowDialog() -ne 'OK'){return}
    try {
        $script:rows=@(Import-Csv -Path $dlg.FileName -Encoding UTF8)
        if($rows.Count -eq 0){throw 'ไฟล์ไม่มีข้อมูล'}
        $bagSeen=@{}
        foreach($vr in $rows){
            $bk=Normalize-BagKey (Row-Value $vr 'Bag_Number')
            if(-not [string]::IsNullOrWhiteSpace($bk)){
                if($bagSeen.ContainsKey($bk)){throw "พบ Bag Number ซ้ำใน CSV: $(Row-Value $vr 'Bag_Number') — หยุดใช้ไฟล์นี้เพื่อป้องกันสลับคน"}
                $bagSeen[$bk]=$true
            }
        }
        $regDone.Clear(); $donDone.Clear(); Clear-RowLock; Populate-Grid; Update-Progress
        $lblFile.Text="$($dlg.FileName) - $($rows.Count) รายการ"
        if($grid.Rows.Count -gt 0){ Refresh-Selected }
    } catch {
        [System.Windows.Forms.MessageBox]::Show(('เปิดไฟล์ไม่สำเร็จ: '+$_.Exception.Message),'CNMI LIS Assistant','OK','Error') | Out-Null
    }
})
$grid.Add_SelectionChanged({
    if($suppressSelection -or $rows.Count -eq 0){return}
    if($lockedStep -ne 0 -and $grid.SelectedRows.Count -gt 0 -and (Row-Key $grid.SelectedRows[0].Tag) -ne $lockedKey){
        $script:suppressSelection=$true
        $grid.ClearSelection(); $grid.CurrentCell=$grid.Rows[$lockedIndex].Cells['DN']; $grid.Rows[$lockedIndex].Selected=$true
        $script:suppressSelection=$false
        [System.Windows.Forms.MessageBox]::Show('กำลังทำคนนี้อยู่ ต้องทำส่วนที่ 1 + ส่วนที่ 2 ให้เสร็จทั้งคนก่อนจึงเปลี่ยนคนได้','Locked Person','OK','Warning') | Out-Null
        return
    }
    $chkIdentity.Checked=$false
    $txtBagVerify.Text=''
    Refresh-Selected
})
$cmbStep.Add_SelectedIndexChanged({ return })
$chkIdentity.Add_CheckedChanged({ if($lockedStep -eq 10){$btnAuto1.Enabled=$chkIdentity.Checked} })
$txtBagVerify.Add_TextChanged({ Update-BagVerification })
$btnSearchId.Add_Click({
    $r=Get-Selected; if($null -eq $r){return}
    $searchId=Preferred-SearchId $r
    if([string]::IsNullOrWhiteSpace($searchId)){[System.Windows.Forms.MessageBox]::Show('คนนี้ไม่มี Donor ID หรือเลขบัตรสำหรับค้น AI-LIS','ค้น AI-LIS','OK','Warning')|Out-Null;return}
    $msg="กำลังค้นคนนี้:`r`n`r`n$(Display-Name $r)`r`nDN $(Row-Value $r 'DN')`r`nSearch ID: $searchId`r`n`r`n1. เปิด AI-LIS และคลิกช่องค้นหา`r`n2. กด Yes`r`n3. กลับไปคลิกช่องค้นหาอีกครั้งภายใน 4 วินาที`r`n`r`nAssistant จะส่ง ID แล้วหยุด จากนั้นตรวจชื่อใน AI-LIS ให้ตรงกับชื่อใหญ่ใน Assistant"
    if(-not (Safe-AutoStart 'เริ่มคนนี้ — ค้น AI-LIS' $msg)){return}
    Set-RowLock $r 10
    try { Paste-Value $searchId $delayMs }
    catch { [System.Windows.Forms.MessageBox]::Show(('ส่ง ID ไม่สำเร็จ: '+$_.Exception.Message),'ค้น AI-LIS','OK','Error')|Out-Null }
    finally { $form.WindowState='Normal'; $form.Activate(); $lblStatus.Text='🔒 คนนี้ถูกล็อกแล้ว → ตรวจชื่อใน AI-LIS → ถ้าตรงให้ติ๊กข้อ 2'; $lblStatus.ForeColor='DarkBlue'; Refresh-Selected }
})
$btnDone1.Add_Click({
    $r=Get-Selected; if($null -eq $r -or $lockedStep -ne 11){return}
    $regDone[(Row-Key $r)]=$true
    $script:lockedStep=20
    $p1.Visible=$false; $p2.Visible=$true
    $chkIdentity.Checked=$false
    Update-Grid-Status; Update-Progress; Refresh-Selected
    $lblStatus.Text="🔒 ส่วนที่ 1 ✓ แล้ว · ทำส่วนที่ 2 ของ $(Display-Name $r) ต่อทันที ห้ามเปลี่ยนคน"
    $lblStatus.ForeColor='DarkBlue'
})
$btnDone2.Add_Click({
    $r=Get-Selected; if($null -eq $r -or $lockedStep -ne 21){return}
    $donDone[(Row-Key $r)]=$true
    Update-Grid-Status; Update-Progress
    $name=Display-Name $r
    Clear-RowLock
    Select-Next
    Refresh-Selected
    $lblStatus.Text="✓ Complete: $name → พร้อมทำคนถัดไป"
    $lblStatus.ForeColor='DarkGreen'
})

$btnAuto1.Add_Click({
    $r=Get-Selected; if($null -eq $r -or $lockedStep -ne 10){return}
    if(-not $chkIdentity.Checked){[System.Windows.Forms.MessageBox]::Show('ต้องค้น AI-LIS และติ๊กยืนยันชื่อให้ตรงก่อน Auto','Auto ส่วนที่ 1','OK','Warning')|Out-Null;return}
    $msg="LOCK คนนี้ก่อน Auto:`r`n`r`n$(Display-Name $r)`r`nDN $(Row-Value $r 'DN')`r`nID Card $(Row-Value $r 'ID_Card')`r`n`r`nคลิกช่อง คำนำหน้า ใน AI-LIS แล้วกด Yes จากนั้นกลับไปคลิกช่องคำนำหน้าอีกครั้งภายใน 4 วินาที`r`n`r`nระบบจะกรอกถึง อาชีพ → โทรศัพท์ และจะไม่ให้เปลี่ยนคนจนกด ✓ บันทึกแล้ว"
    if(-not (Safe-AutoStart 'Auto ส่วนที่ 1 — Locked Person' $msg)){return}
    $script:lockedStep=11
    $btnAuto1.Enabled=$false; $btnDone1.Enabled=$true
    try {
        # Exact sequence: Prefix -> TAB -> skip Use ID Card -> TAB -> FirstName -> LastName -> Birthdate -> ID Card
        # -> TAB x5 -> Address -> Subdistrict -> District -> Province -> Postal Code -> Occupation -> Phone -> stop.
        Paste-Value (Normalize-Prefix (Row-Value $r 'Prefix')) $delayMs
        Send-Tab 2 $delayMs
        Paste-Value (Row-Value $r 'FirstName') $delayMs
        Send-Tab 1 $delayMs
        Paste-Value (Row-Value $r 'LastName') $delayMs
        Send-Tab 1 $delayMs
        Paste-Value (Normalize-BirthdateForLis (Row-Value $r 'Birthdate')) $delayMs
        Send-Tab 1 $delayMs
        Paste-Value (Row-Value $r 'ID_Card') $delayMs
        Send-Tab 5 $delayMs
        Paste-Value (Row-Value $r 'Address') $delayMs
        Send-Tab 1 $slowDelayMs
        Paste-Value (Row-Value $r 'Subdistrict') $slowDelayMs
        Send-Tab 1 $slowDelayMs
        Paste-Value (Row-Value $r 'District') $slowDelayMs
        Send-Tab 1 $slowDelayMs
        Paste-Value (Row-Value $r 'Province') $slowDelayMs
        Send-Tab 1 $slowDelayMs
        Paste-Value (Row-Value $r 'Postal_Code') $delayMs
        Send-Tab 1 $delayMs
        Select-LisOccupation (Row-Value $r 'Occupation') $slowDelayMs
        Send-Tab 1 $delayMs
        Paste-Value (Row-Value $r 'Phone') $delayMs
    } catch {
        [System.Windows.Forms.MessageBox]::Show(('Auto ส่วนที่ 1 หยุด: '+$_.Exception.Message),'CNMI LIS Assistant','OK','Error') | Out-Null
    } finally {
        $form.WindowState='Normal'; $form.Activate(); $lblStatus.Text="🔒 $(Display-Name $r) · ตรวจส่วนที่ 1 และกดบันทึกใน AI-LIS → แล้วกด ✓ ไปส่วนที่ 2 ของคนเดิม"; $lblStatus.ForeColor='DarkRed'
    }
})

$btnAuto2.Add_Click({
    $r=Get-Selected; if($null -eq $r -or $lockedStep -ne 20){return}
    $status=Row-Value $r 'Screening_Status'
    $safety=Safety-Text $r

    if($status -eq 'ไม่ผ่าน'){
        if($safety.StartsWith('ERROR')){[System.Windows.Forms.MessageBox]::Show($safety,'Auto ส่วนที่ 2','OK','Warning')|Out-Null;return}
        $msg="LOCK คนนี้ก่อน Auto:`r`n`r`n$(Display-Name $r)`r`nDN $(Row-Value $r 'DN')`r`nผล: ไม่ผ่าน`r`n`r`nระบบจะลงเฉพาะ Weight / BP / Pulse / Temperature / Hb แล้วหยุดทันที`r`nจะไม่แตะ Bag Number / V / Group / Bag Lot`r`n`r`nคลิกช่อง น้ำหนัก ใน AI-LIS แล้วกด Yes จากนั้นกลับไปคลิกช่องน้ำหนักอีกครั้งภายใน 4 วินาที"
        if(-not (Safe-AutoStart 'Auto ส่วนที่ 2 — ไม่ผ่าน (5 ค่า)' $msg)){return}
        $script:lockedStep=21
        $btnAuto2.Enabled=$false; $btnDone2.Enabled=$true
        try {
            # Failed donor: enter only five screening values and STOP on Hb.
            $fields=@('Weight','BP','Pulse','Temperature','Hb')
            for($i=0; $i -lt $fields.Count; $i++){
                $v=Row-Value $r $fields[$i]
                if(-not [string]::IsNullOrWhiteSpace($v)) { Paste-Value $v $delayMs }
                if($i -lt ($fields.Count-1)) { Send-Tab 1 $delayMs }
            }
        } catch {
            [System.Windows.Forms.MessageBox]::Show(('Auto ส่วนที่ 2 หยุด: '+$_.Exception.Message),'CNMI LIS Assistant','OK','Error') | Out-Null
        } finally {
            $form.WindowState='Normal'; $form.Activate(); $lblStatus.Text="🔒 $(Display-Name $r) · ไม่ผ่าน → ตรวจ 5 ค่าและบันทึกใน AI-LIS → กด ✓ เสร็จทั้งคนนี้"; $lblStatus.ForeColor='DarkRed'
        }
        return
    }

    if($status -ne 'ผ่าน'){
        [System.Windows.Forms.MessageBox]::Show('ต้องมีผลคัดกรอง ผ่าน หรือ ไม่ผ่าน ก่อนใช้ Auto ส่วนที่ 2','Auto ส่วนที่ 2','OK','Warning')|Out-Null;return
    }
    if($safety -ne 'OK'){
        [System.Windows.Forms.MessageBox]::Show('ผู้บริจาคที่ผ่านต้องมี Bag Number + Bag Lot ครบก่อน','Auto ส่วนที่ 2','OK','Warning')|Out-Null;return
    }
    if((Normalize-BagKey $txtBagVerify.Text) -ne (Normalize-BagKey (Row-Value $r 'Bag_Number'))){[System.Windows.Forms.MessageBox]::Show('ต้องยิง Barcode ถุงให้ตรง Expected Bag ก่อน','Auto ส่วนที่ 2','OK','Warning')|Out-Null;return}
    $msg="LOCK คนนี้ก่อน Auto:`r`n`r`n$(Display-Name $r)`r`nDN $(Row-Value $r 'DN')`r`nExpected Bag: $(Row-Value $r 'Bag_Number')`r`nGroup: $(Row-Value $r 'Blood_Group')`r`nBag Lot: $(Row-Value $r 'Bag_Lot')`r`n`r`nBarcode ถุงยืนยันตรงแล้ว`r`nคลิกช่อง น้ำหนัก ใน AI-LIS แล้วกด Yes จากนั้นกลับไปคลิกช่องน้ำหนักอีกครั้งภายใน 4 วินาที"
    if(-not (Safe-AutoStart 'Auto ส่วนที่ 2 — ผ่าน (Locked Person)' $msg)){return}
    $script:lockedStep=21
    $btnAuto2.Enabled=$false; $btnDone2.Enabled=$true
    try {
        # Passed donor sequence:
        # Weight -> BP -> Pulse -> Temperature -> Hb -> Bag Number -> TAB x2 -> V -> TAB x3 -> Group (ENTER) -> TAB x4 -> Bag Lot -> stop.
        $fields=@('Weight','BP','Pulse','Temperature','Hb')
        foreach($field in $fields) {
            $v=Row-Value $r $field
            if(-not [string]::IsNullOrWhiteSpace($v)) { Paste-Value $v $delayMs }
            Send-Tab 1 $delayMs
        }
        Paste-Value (Row-Value $r 'Bag_Number') $delayMs
        Send-Tab 2 $delayMs
        Paste-Value 'V' $delayMs
        Send-Tab 3 $delayMs
        Select-LisBloodGroup (Row-Value $r 'Blood_Group') $slowDelayMs
        Send-Tab 4 $delayMs
        Paste-Value (Row-Value $r 'Bag_Lot') $slowDelayMs
    } catch {
        [System.Windows.Forms.MessageBox]::Show(('Auto ส่วนที่ 2 หยุด: '+$_.Exception.Message),'CNMI LIS Assistant','OK','Error') | Out-Null
    } finally {
        $form.WindowState='Normal'; $form.Activate(); $lblStatus.Text="🔒 $(Display-Name $r) · ตรวจ 5 ค่า + Bag + V + Group + Bag Lot และบันทึก → กด ✓ เสร็จทั้งคนนี้"; $lblStatus.ForeColor='DarkRed'
    }
})

[void]$form.ShowDialog()
