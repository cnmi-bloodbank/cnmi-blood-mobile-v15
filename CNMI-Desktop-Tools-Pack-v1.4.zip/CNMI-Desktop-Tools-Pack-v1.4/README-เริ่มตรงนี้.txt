CNMI Desktop Tools Pack v1.4

ประกอบด้วย
- CNMI Card Bridge v1.1 (แก้ Windows PowerShell UTF-8/ภาษาไทย ParserError)
- CNMI Scan Bridge v1.3
- CNMI LIS Assistant v2.14

สำหรับ Card Bridge: แตก ZIP ของ CNMI-Card-Bridge-v1.1.zip แล้วเปิด Start-CNMI-Card-Bridge.cmd
