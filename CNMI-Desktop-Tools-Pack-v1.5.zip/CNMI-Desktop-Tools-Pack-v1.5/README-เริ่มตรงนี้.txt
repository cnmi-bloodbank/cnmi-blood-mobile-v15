CNMI Desktop Tools Pack v1.5

ประกอบด้วย
- CNMI Card Bridge v1.1
- CNMI Scan Bridge v1.3
- CNMI LIS Assistant v2.15 — Safe Back + Resume

LIS Assistant v2.15
- ถ้าลงผิดสามารถย้อนเฉพาะคนปัจจุบันได้ ไม่ต้องเริ่มจากคนที่ 1
- คนที่ Complete แล้วสามารถเปิดแก้ได้
- บันทึก Progress ข้าง CSV และ Resume ได้เมื่อเปิดไฟล์เดิมใหม่

สำหรับ Card Bridge: แตก ZIP ของ CNMI-Card-Bridge-v1.1.zip แล้วเปิด Start-CNMI-Card-Bridge.cmd
