CNMI Desktop Tools Pack v1.2

มี 3 โปรแกรมสำหรับคอมที่ใช้ Blood Mobile
1) CNMI Card Bridge v1.0 — เปิดค้างไว้เมื่ออ่านบัตรประชาชนจาก Smart Card Reader
2) CNMI Scan Bridge v1.3 — เปิดค้างไว้เมื่อสแกนบัตร/ใบขับขี่จาก HP Scanner
3) CNMI LIS Assistant v2.13 — นำข้อมูลกลับเข้า AI-LIS แบบทำทีละคนให้จบทั้งส่วน 1 + 2

แต่ละโปรแกรมเป็น ZIP แยก ให้แตก ZIP ของโปรแกรมนั้นก่อนใช้งาน
