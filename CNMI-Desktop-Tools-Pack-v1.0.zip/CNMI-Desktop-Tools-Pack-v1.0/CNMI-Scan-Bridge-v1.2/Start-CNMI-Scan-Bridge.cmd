﻿@echo off
chcp 65001 >nul
title CNMI Scan Bridge v1.2
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0CNMI-Scan-Bridge.ps1"
if errorlevel 1 pause
