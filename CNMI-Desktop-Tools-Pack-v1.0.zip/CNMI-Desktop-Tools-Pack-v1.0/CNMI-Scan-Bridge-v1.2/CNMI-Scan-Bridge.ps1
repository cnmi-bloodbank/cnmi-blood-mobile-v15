﻿# CNMI Scan Bridge v1.2
# Local-only bridge: Blood Mobile (browser) -> Windows WIA scanner
# Direct flatbed scan: no WIA wizard. Scan card-sized region @ ~300 dpi, then optimize JPEG before returning to browser.
# Listens only on 127.0.0.1:27101 and does not upload/store scanned images.

$ErrorActionPreference = 'Stop'
$Port = 27101
$TargetDpi = 300

function New-Json([hashtable]$obj) {
    return ($obj | ConvertTo-Json -Compress -Depth 6)
}

function Send-HttpResponse {
    param(
        [System.Net.Sockets.TcpClient]$Client,
        [int]$StatusCode = 200,
        [string]$StatusText = 'OK',
        [string]$ContentType = 'application/json; charset=utf-8',
        [string]$Body = ''
    )
    $stream = $Client.GetStream()
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    $bodyBytes = $utf8.GetBytes($Body)
    $headers = "HTTP/1.1 $StatusCode $StatusText`r`n" +
               "Content-Type: $ContentType`r`n" +
               "Content-Length: $($bodyBytes.Length)`r`n" +
               "Access-Control-Allow-Origin: *`r`n" +
               "Access-Control-Allow-Methods: GET, OPTIONS`r`n" +
               "Access-Control-Allow-Headers: Content-Type`r`n" +
               "Access-Control-Allow-Private-Network: true`r`n" +
               "Cache-Control: no-store`r`n" +
               "Connection: close`r`n`r`n"
    $headerBytes = $utf8.GetBytes($headers)
    $stream.Write($headerBytes,0,$headerBytes.Length)
    if($bodyBytes.Length -gt 0){ $stream.Write($bodyBytes,0,$bodyBytes.Length) }
    $stream.Flush()
}

function Get-WiaProperty {
    param($Properties, [int]$PropertyId)
    foreach($p in $Properties){
        try { if([int]$p.PropertyID -eq $PropertyId){ return $p } } catch {}
    }
    return $null
}

function Set-WiaPropertySafe {
    param($Properties, [int]$PropertyId, $Value)
    try {
        $p = Get-WiaProperty -Properties $Properties -PropertyId $PropertyId
        if($null -ne $p){ $p.Value = $Value; return $true }
    } catch {}
    return $false
}

function Get-ScannerName {
    param($DeviceInfo)
    try {
        foreach($p in $DeviceInfo.Properties){
            if([string]$p.Name -eq 'Name'){ return [string]$p.Value }
        }
    } catch {}
    try { return [string]$DeviceInfo.Properties.Item('Name').Value } catch {}
    return 'Scanner'
}

function Select-ScannerDeviceInfo {
    $manager = New-Object -ComObject 'WIA.DeviceManager'
    $scanners = @()
    foreach($info in $manager.DeviceInfos){
        try {
            if([int]$info.Type -eq 1){
                $scanners += [pscustomobject]@{ Info=$info; Name=(Get-ScannerName $info) }
            }
        } catch {}
    }
    if($scanners.Count -eq 0){ throw 'ไม่พบ Scanner/WIA ใน Windows' }

    # Prefer the HP model used by CNMI.
    $preferred = $scanners | Where-Object { $_.Name -match 'M426|M427|HP\s+LJ|LaserJet' } | Select-Object -First 1
    if($null -eq $preferred){ $preferred = $scanners | Select-Object -First 1 }
    return $preferred
}

function Configure-FlatbedScan {
    param($Item)
    $props = $Item.Properties

    # WIA_IPS_CUR_INTENT = 6146; 1 = Color intent on most WIA drivers.
    [void](Set-WiaPropertySafe $props 6146 1)
    # Resolution.
    [void](Set-WiaPropertySafe $props 6147 $TargetDpi) # XRES
    [void](Set-WiaPropertySafe $props 6148 $TargetDpi) # YRES
    # Scan from upper-left of the flatbed.
    [void](Set-WiaPropertySafe $props 6149 0) # XPOS
    [void](Set-WiaPropertySafe $props 6150 0) # YPOS

    # Scan only the upper-left card area instead of the whole A4 flatbed.
    # Approx. 4.0 x 3.0 inches at 300 dpi = 1200 x 900 px, enough for Thai ID / driving licence with margin.
    try {
        $px = Get-WiaProperty $props 6151 # XEXTENT
        if($null -ne $px){
            $targetX = [int](4.0 * $TargetDpi)
            if($null -ne $px.SubTypeMax){ $targetX = [Math]::Min($targetX,[int]$px.SubTypeMax) }
            if($null -ne $px.SubTypeMin){ $targetX = [Math]::Max($targetX,[int]$px.SubTypeMin) }
            $px.Value = $targetX
        }
    } catch {}
    try {
        $py = Get-WiaProperty $props 6152 # YEXTENT
        if($null -ne $py){
            $targetY = [int](3.0 * $TargetDpi)
            if($null -ne $py.SubTypeMax){ $targetY = [Math]::Min($targetY,[int]$py.SubTypeMax) }
            if($null -ne $py.SubTypeMin){ $targetY = [Math]::Max($targetY,[int]$py.SubTypeMin) }
            $py.Value = $targetY
        }
    } catch {}
}


function Optimize-ScanJpeg {
    param([string]$InputPath, [string]$OutputPath)
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
        $src = [System.Drawing.Image]::FromFile($InputPath)
        try {
            $maxW = 1800
            $maxH = 1400
            $scale = [Math]::Min([Math]::Min($maxW / [double]$src.Width, $maxH / [double]$src.Height), 1.0)
            $w = [Math]::Max(1,[int][Math]::Round($src.Width * $scale))
            $h = [Math]::Max(1,[int][Math]::Round($src.Height * $scale))
            $bmp = New-Object System.Drawing.Bitmap($w,$h)
            try {
                $g = [System.Drawing.Graphics]::FromImage($bmp)
                try {
                    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $g.DrawImage($src,0,0,$w,$h)
                } finally { $g.Dispose() }
                $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' } | Select-Object -First 1
                $enc = New-Object System.Drawing.Imaging.EncoderParameters(1)
                $enc.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality,[long]88)
                $bmp.Save($OutputPath,$codec,$enc)
                $enc.Dispose()
            } finally { $bmp.Dispose() }
        } finally { $src.Dispose() }
        return (Test-Path $OutputPath)
    } catch {
        return $false
    }
}

function Acquire-Scan {
    try {
        $picked = Select-ScannerDeviceInfo
        $device = $picked.Info.Connect()
        if($null -eq $device){ throw 'เชื่อมต่อ Scanner ไม่สำเร็จ' }
        if($device.Items.Count -lt 1){ throw 'Scanner ไม่มีรายการ Flatbed ที่ใช้งานได้' }
        $item = $device.Items.Item(1)
        Configure-FlatbedScan -Item $item

        $jpeg = '{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}'
        $image = $item.Transfer($jpeg)
        if($null -eq $image){ throw 'ไม่ได้รับภาพจาก Scanner' }

        $tmp = Join-Path $env:TEMP (('CNMI-Scan-' + [guid]::NewGuid().ToString('N')) + '.jpg')
        $optimized = Join-Path $env:TEMP (('CNMI-Scan-Optimized-' + [guid]::NewGuid().ToString('N')) + '.jpg')
        try {
            $image.SaveFile($tmp)
            $usePath = $tmp
            if(Optimize-ScanJpeg -InputPath $tmp -OutputPath $optimized){ $usePath = $optimized }
            $bytes = [System.IO.File]::ReadAllBytes($usePath)
            if($bytes.Length -le 0){ throw 'ไม่ได้รับข้อมูลภาพจาก Scanner' }
            if($bytes.Length -gt 12000000){ throw 'ไฟล์ Scan ยังมีขนาดใหญ่เกิน 12 MB หลังย่อภาพ กรุณาตรวจ Driver Scanner' }
            $b64 = [Convert]::ToBase64String($bytes)
            return @{
                ok=$true
                imageData=('data:image/jpeg;base64,' + $b64)
                bytes=$bytes.Length
                scanner=$picked.Name
                dpi=$TargetDpi
                mode='direct-card-flatbed-optimized'
            }
        } finally {
            if(Test-Path $tmp){ Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
            if(Test-Path $optimized){ Remove-Item $optimized -Force -ErrorAction SilentlyContinue }
        }
    } catch {
        $msg = $_.Exception.Message
        if($msg -match '0x80210064|cancel|ยกเลิก'){
            return @{ ok=$false; cancelled=$true; message='ยกเลิกการสแกน' }
        }
        return @{ ok=$false; cancelled=$false; message=('สแกนไม่สำเร็จ: ' + $msg) }
    }
}

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback,$Port)
try {
    $listener.Start()
} catch {
    Write-Host ''
    Write-Host "เปิด CNMI Scan Bridge ไม่สำเร็จ: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "ถ้ามี Scan Bridge เปิดอยู่แล้ว ให้ปิดหน้าต่างเดิมก่อน" -ForegroundColor Yellow
    Read-Host 'กด Enter เพื่อปิด'
    exit 1
}

Write-Host 'CNMI Scan Bridge v1.2' -ForegroundColor Cyan
Write-Host "พร้อมใช้งานที่ http://127.0.0.1:$Port" -ForegroundColor Green
Write-Host 'โหมด: Flatbed เฉพาะพื้นที่บัตร ~300 dpi + ย่อ JPEG อัตโนมัติ' -ForegroundColor Green
Write-Host 'วางบัตรคว่ำหน้า ชิดมุมซ้ายบนของกระจก แล้วกดสแกนจาก Blood Mobile ได้เลย' -ForegroundColor Yellow
Write-Host 'ภาพ Scan ส่งให้ Browser ในเครื่องนี้เท่านั้น และลบไฟล์ชั่วคราวทันที' -ForegroundColor DarkGray
Write-Host ''

try {
    while($true){
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream,[System.Text.Encoding]::ASCII,$false,4096,$true)
            $requestLine = $reader.ReadLine()
            if([string]::IsNullOrWhiteSpace($requestLine)){
                Send-HttpResponse -Client $client -StatusCode 400 -StatusText 'Bad Request' -Body (New-Json @{ok=$false;message='Bad request'})
                continue
            }
            do { $line=$reader.ReadLine() } while($null -ne $line -and $line -ne '')
            $parts = $requestLine.Split(' ')
            $method = if($parts.Length -gt 0){$parts[0]}else{''}
            $path = if($parts.Length -gt 1){$parts[1].Split('?')[0]}else{'/'}

            if($method -eq 'OPTIONS'){
                Send-HttpResponse -Client $client -StatusCode 204 -StatusText 'No Content' -Body ''
            } elseif($method -ne 'GET'){
                Send-HttpResponse -Client $client -StatusCode 405 -StatusText 'Method Not Allowed' -Body (New-Json @{ok=$false;message='GET only'})
            } elseif($path -eq '/health'){
                Send-HttpResponse -Client $client -Body (New-Json @{ok=$true;name='CNMI Scan Bridge';version='1.2';mode='direct-card-flatbed-optimized';dpi=$TargetDpi})
            } elseif($path -eq '/scan'){
                Write-Host ('[' + (Get-Date -Format 'HH:mm:ss') + '] เริ่มสแกนพื้นที่บัตรอัตโนมัติ...') -ForegroundColor Cyan
                $result = Acquire-Scan
                if($result.ok){
                    Write-Host ('[' + (Get-Date -Format 'HH:mm:ss') + '] สแกนสำเร็จ · ' + $result.scanner + ' · ' + $result.dpi + ' dpi') -ForegroundColor Green
                } elseif($result.cancelled){
                    Write-Host ('[' + (Get-Date -Format 'HH:mm:ss') + '] ยกเลิกการสแกน') -ForegroundColor Yellow
                } else {
                    Write-Host ('[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $result.message) -ForegroundColor Red
                }
                Send-HttpResponse -Client $client -Body (New-Json $result)
            } else {
                Send-HttpResponse -Client $client -StatusCode 404 -StatusText 'Not Found' -Body (New-Json @{ok=$false;message='Not found'})
            }
        } catch {
            try { Send-HttpResponse -Client $client -StatusCode 500 -StatusText 'Server Error' -Body (New-Json @{ok=$false;message=$_.Exception.Message}) } catch {}
        } finally {
            $client.Close()
        }
    }
} finally {
    $listener.Stop()
}
